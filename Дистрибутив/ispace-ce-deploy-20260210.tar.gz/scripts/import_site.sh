#!/bin/bash

# Скрипт для импорта коллекций MongoDB
# Использование: ./mongo_import.sh [OPTIONS]
# 
# Опции:
#   -f, --family FAMILY    Имя семейства коллекций (обязательно)
#   -d, --database DB      Имя базы данных (по умолчанию: iSpaceContent)
#   -u, --user USERNAME    Имя пользователя admin
#   -p, --password PASS    Пароль admin
#   -i, --input FILE       Имя входного файла/префикса
#   -h, --host HOST        Хост MongoDB (по умолчанию: localhost:27017)
#   --env-file FILE        Файл с переменными окружения (по умолчанию: .env)
#   --drop                 Удалять коллекции перед импортом

set -e

# Значения по умолчания
DB_NAME="iSpaceContent"
HOST="localhost:27017"
ENV_FILE=".env"
AUTH_DB="admin"
DROP_COLLECTIONS=false

# Парсинг аргументов
while [[ $# -gt 0 ]]; do
    case $1 in
        -s|--site)
            COLLECTION_FAMILY="$2"
            shift
            shift
            ;;
        -d|--database)
            DB_NAME="$2"
            shift
            shift
            ;;
        -u|--user)
            MONGO_USER="$2"
            shift
            shift
            ;;
        -p|--password)
            MONGO_PASSWORD="$2"
            shift
            shift
            ;;
        -h|--host)
            HOST="$2"
            shift
            shift
            ;;
        -b|--backupdir)
            BACKUP_DIR="$2"
            shift
            shift
            ;;
        --env-file)
            ENV_FILE="$2"
            shift
            shift
            ;;
        --drop)
            DROP_COLLECTIONS=false
            shift
            ;;
        *)
            echo "Неизвестный параметр: $1"
            exit 1
            ;;
    esac
done

# Загрузка переменных из .env файла
if [[ -f "$ENV_FILE" ]]; then
    echo "Загружаем переменные из $ENV_FILE"
    set -a
    source "$ENV_FILE"
    set +a
fi

# Установка учетных данных
if [[ -z "$MONGO_USER" ]]; then
    MONGO_USER="${MONGO_INITDB_ROOT_USERNAME}"
fi

if [[ -z "$MONGO_PASSWORD" ]]; then
    MONGO_PASSWORD="${MONGO_INITDB_ROOT_PASSWORD}"
fi

# Проверка обязательных параметров
if [[ -z "$COLLECTION_FAMILY" || -z "$BACKUP_DIR" ]]; then
    echo "Ошибка: Имя сайта и путь до файлов для загрузки обязательно"
    echo "Использование: $0 -s SITE_ID -b path"
    exit 1
fi

if [[ -z "$MONGO_USER" || -z "$MONGO_PASSWORD" ]]; then
    echo "Ошибка: Не указаны учетные данные MongoDB"
    echo "Укажите через параметры или переменные среды MONGO_INITDB_ROOT_USERNAME/MONGO_INITDB_ROOT_PASSWORD"
    exit 1
fi

echo "=== Импорт коллекций MongoDB ==="
echo "База данных: $DB_NAME"
echo "Сайт: $COLLECTION_FAMILY"
echo "Хост: $HOST"
echo "Директория: $BACKUP_DIR"
echo "Режим drop: $DROP_COLLECTIONS"

# Поиск файлов для импорта
FILES=$(find "$BACKUP_DIR" -name "*.json" -type f | sort)

if [[ -z "$FILES" ]]; then
    echo "Не найдено файлов для импорта с шаблоном: .*.json"
    echo "Доступные файлы в $BACKUP_DIR:"
    ls -la "$BACKUP_DIR"/*.json 2>/dev/null || echo "Файлы не найдены"
    exit 1
fi

echo "Найдены файлы для импорта:"
echo "$FILES"

# Импортируем каждую коллекцию
for file in $FILES; do
    # Извлекаем имя коллекции из имени файла
    filename=$(basename "$file")

    # Автоматически заменяем префикс до первой точки
    collection_name="${COLLECTION_FAMILY}.${filename#*.}"  # заменяем префикс
    collection_name="${collection_name%.json}"  # убираем .json    
    
    echo "Импортируем коллекцию: $collection_name из файла: $file"
    
    # Опция --drop если указана
    DROP_OPTION=""
    if [[ "$DROP_COLLECTIONS" == true ]]; then
        DROP_OPTION="--drop"
        echo "Удаляем существующую коллекцию: $collection_name"
    fi
done
exit 0
    docker compose exec mongodb mongoimport \
        --host "$HOST" \
        --db "$DB_NAME" \
        --collection "$collection_name" \
        --username "$MONGO_USER" \
        --password "$MONGO_PASSWORD" \
        --authenticationDatabase "$AUTH_DB" \
        $DROP_OPTION \
        --file "$file"
    
    if [[ $? -eq 0 ]]; then
        echo "✓ Успешно импортирована: $collection_name"
    else
        echo "✗ Ошибка при импорте: $collection_name"
        exit 1
    fi
#done

echo "=== Импорт завершен ==="
echo "Импортированные коллекции:"
echo "$FILES"
