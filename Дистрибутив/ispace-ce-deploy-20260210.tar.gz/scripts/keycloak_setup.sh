#!/bin/bash

# Load configuration from external file
ENV_FILE=".env"
CONFIG_FILE="keycloak/keycloak_config.env"

source $ENV_FILE
source $CONFIG_FILE

KEYCLOAK_URL="https://${KC_HOSTNAME}:${KC_HTTPS_PORT}"
KEYCLOAK_ADMIN_USERNAME=${KC_BOOTSTRAP_ADMIN_USERNAME}
KEYCLOAK_ADMIN_PASSWORD=${KC_BOOTSTRAP_ADMIN_PASSWORD}

echo ">>> ${KEYCLOAK_URL}"

# Function to get admin access token
get_admin_token() {
    curl -k -s -X POST \
        -H "Content-Type: application/x-www-form-urlencoded" \
        -d "username=$KEYCLOAK_ADMIN_USERNAME" \
        -d "password=$KEYCLOAK_ADMIN_PASSWORD" \
        -d "grant_type=password" \
        -d "client_id=admin-cli" \
        "$KEYCLOAK_URL/realms/master/protocol/openid-connect/token" | jq -r '.access_token'
}

# Function to check if realm exists
realm_exists() {
    local token=$1
    local realm_name=$2
    curl -k -s -X GET \
        -H "Authorization: Bearer $token" \
        "$KEYCLOAK_URL/admin/realms/$realm_name" | jq -r '.realm' 2>/dev/null
}

# Function to create realm
create_realm() {
    local token=$1
    curl -k -s -X POST \
        -H "Authorization: Bearer $token" \
        -H "Content-Type: application/json" \
        -d '{
            "realm": "'"$REALM_NAME"'",
            "displayName": "'"$REALM_DISPLAY_NAME"'",
            "enabled": "'"$REALM_ENABLED"'"
        }' \
        "$KEYCLOAK_URL/admin/realms"
}

# Function to get realm public key
get_realm_public_key() {
    local token=$1
    curl -k -s -X GET  \
	-H "Authorization: Bearer $token" \
	"$KEYCLOAK_URL/realms/$REALM_NAME" | jq -r '.public_key'
}

# Function to get client uuid
get_client_uuid() {
    local token=$1

    curl -k -s -X GET  \
	-H "Authorization: Bearer $token" \
	"$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients?clientId=$CLIENT_ID" | jq -r '.[0].id'
}
# Function to create client
create_client() {
    local token=$1

    curl -k -s -w "%{http_code}" -X POST \
        -H "Authorization: Bearer $token" \
        -H "Content-Type: application/json" \
        -d '{
            "clientId": "'"$CLIENT_ID"'",
            "name": "'"$CLIENT_NAME"'",
            "enabled": '"$CLIENT_ENABLED"',
            "publicClient": '"$CLIENT_PUBLIC"',
            "directAccessGrantsEnabled": '"$CLIENT_DIRECT_ACCESS_GRANTS"',
            "serviceAccountsEnabled": '"$CLIENT_SERVICE_ACCOUNTS_ENABLED"'
        }' \
        "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients"
}

# Function to get client secret
get_client_secret() {
    local token=$1
    local client_id=$2
    
    # Get client internal ID
    local client_uuid=$(curl -k -s -X GET \
        -H "Authorization: Bearer $token" \
        "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients?clientId=$client_id" | jq -r '.[0].id')
    
    if [ -z "$client_uuid" ] || [ "$client_uuid" == "null" ]; then
        echo "Error: Client '$client_id' not found" >&2
        return 1
    fi
    
    # Get client secret
    curl -k -s -X GET \
        -H "Authorization: Bearer $token" \
        "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$client_uuid/client-secret" | jq -r '.value'
}

# Function to create client roles
create_client_roles() {
    local token=$1
    local client_id=$2
    local roles=$3
    
    # Get client internal ID
    local client_uuid=$(curl -k -s -X GET \
        -H "Authorization: Bearer $token" \
        "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients?clientId=$client_id" | jq -r '.[0].id')
    
    if [ -z "$client_uuid" ] || [ "$client_uuid" == "null" ]; then
        echo "Error: Client '$client_id' not found for role creation" >&2
        return 1
    fi
    
    # Create each role
    IFS=',' read -ra ROLES_ARRAY <<< "$roles"
    for role in "${ROLES_ARRAY[@]}"; do
        role=$(echo "$role" | xargs) # Trim whitespace
        echo "Creating client role: $role"
        
        curl -k -s -X POST \
            -H "Authorization: Bearer $token" \
            -H "Content-Type: application/json" \
            -d '{
                "name": "'"$role"'",
                "description": "'"$role"' role"
            }' \
            "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$client_uuid/roles"
    done
}

# Function to set service account roles
set_service_account_roles() {
    local token=$1
    local client_id=$2
    local roles=$3
    
    # Get client internal ID
    local client_uuid=$(curl -k -s -X GET \
        -H "Authorization: Bearer $token" \
        "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients?clientId=$client_id" | jq -r '.[0].id')
    
    if [ -z "$client_uuid" ] || [ "$client_uuid" == "null" ]; then
        echo "Error: Client '$client_id' not found for service account configuration" >&2
        return 1
    fi
    
    # Get service account user ID
    local service_account_id=$(curl -k -s -X GET \
        -H "Authorization: Bearer $token" \
        "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$client_uuid/service-account-user" | jq -r '.id')
    
    # Assign each role to service account
    IFS=',' read -ra ROLES_ARRAY <<< "$roles"
    for role in "${ROLES_ARRAY[@]}"; do
        role=$(echo "$role" | xargs) # Trim whitespace
        
        # Find the role ID
        local role_id=$(curl -k -s -X GET \
            -H "Authorization: Bearer $token" \
            "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$client_uuid/roles/$role" | jq -r '.id')
        
        if [ -n "$role_id" ] && [ "$role_id" != "null" ]; then
            echo "Assigning role to service account: $role"
            
            # Assign role to service account
            curl -k -s -X POST \
                -H "Authorization: Bearer $token" \
                -H "Content-Type: application/json" \
                -d '[{
                    "id": "'"$role_id"'",
                    "name": "'"$role"'"
                }]' \
                "$KEYCLOAK_URL/admin/realms/$REALM_NAME/users/$service_account_id/role-mappings/clients/$client_uuid"
        else
            echo "Warning: Role '$role' not found for client '$client_id'" >&2
        fi
    done
}

# Function to set service account roles
set_service_account_roles_rm() {
    local token=$1
    local client_id=$2
    local roles=$3
    
    # Get client internal ID
    local client_uuid=$(curl -k -s -X GET \
        -H "Authorization: Bearer $token" \
        "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients?clientId=$client_id" | jq -r '.[0].id')
    
    if [ -z "$client_uuid" ] || [ "$client_uuid" == "null" ]; then
        echo "Error: Client '$client_id' not found for service account configuration" >&2
        return 1
    fi

    local client_uuid_rm=$(curl -k -s -X GET \
        -H "Authorization: Bearer $token" \
        "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients?clientId=realm-management" | jq -r '.[0].id')
    
    if [ -z "$client_uuid_rm" ] || [ "$client_uuid_rm" == "null" ]; then
        echo "Error: Client 'realm-management' not found for service account configuration" >&2
        return 1
    fi
    
    # Get service account user ID
    local service_account_id=$(curl -k -s -X GET \
        -H "Authorization: Bearer $token" \
        "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$client_uuid/service-account-user" | jq -r '.id')

    # Assign each role to service account
    IFS=',' read -ra ROLES_ARRAY <<< "$roles"
    for role in "${ROLES_ARRAY[@]}"; do
        role=$(echo "$role" | xargs) # Trim whitespace
        
        # Find the role ID
        local role_id=$(curl -k -s -X GET \
            -H "Authorization: Bearer $token" \
            "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$client_uuid_rm/roles/$role" | jq -r '.id')
        
        if [ -n "$role_id" ] && [ "$role_id" != "null" ]; then
            echo "Assigning role to service account: $role"
            
            # Assign role to service account
            curl -k -s -X POST \
                -H "Authorization: Bearer $token" \
                -H "Content-Type: application/json" \
                -d '[{
                    "id": "'"$role_id"'",
                    "name": "'"$role"'"
                }]' \
                "$KEYCLOAK_URL/admin/realms/$REALM_NAME/users/$service_account_id/role-mappings/clients/$client_uuid_rm"
        else
            echo "Warning: Role '$role' not found for client '$client_id'" >&2
        fi
    done
}

# Function to set default realm role
set_default_realm_role() {
    local token=$1
    local client_id=$2
    local role_name=$3
    
    # Get client internal ID
    local client_uuid=$(curl -k -s -X GET \
        -H "Authorization: Bearer $token" \
        "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients?clientId=$client_id" | jq -r '.[0].id')
    
    if [ -z "$client_uuid" ] || [ "$client_uuid" == "null" ]; then
        echo "Error: Client '$client_id' not found for default role assigning" >&2
        return 1
    fi

    # Find the role ID
    local role_id=$(curl -k -s -X GET \
        -H "Authorization: Bearer $token" \
        "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$client_uuid/roles/$role_name" | jq -r '.id')

    # Find the default composite role ID
    #local default_role_id=${curl -k -s -X GET \
    local default_role_id=$(curl -k -s -X GET \
        -H "Authorization: Bearer $token" \
	"$KEYCLOAK_URL/admin/realms/$REALM_NAME/roles" | jq -r '.[] | select(.composite == true) | .id')

    if [ -n "$role_id" ] && [ "$role_id" != "null" ] && [ -n "$default_role_id" ] && [ "$defaultrole_id" != "null" ]; then
        echo "Assigning default realm role : $role_name"

        # Update realm to set default role
        curl -k -s -X POST \
            -H "Authorization: Bearer $token" \
            -H "Content-Type: application/json" \
            -d '[{
		"id": "'"$role_id"'",
                "name": "'"$role_name"'"
            }]' \
            "$KEYCLOAK_URL/admin/realms/$REALM_NAME/roles-by-id/$default_role_id/composites"
    else
        echo "Warning: Realm role '$role_name' not found" >&2
    fi
}

# Function to create roles mapper in client scopes
create_roles_mapper() {
    local token=$1
    
    # Get default client scopes for realm
    local scope_id=$(curl -k -s -X GET \
        -H "Authorization: Bearer $token" \
	"$KEYCLOAK_URL/admin/realms/$REALM_NAME/default-default-client-scopes" | jq -r '.[] | select(.name == "roles") | .id')
    
    if [ -n "$scope_id" ] && [ "$scope_id" != "null" ]; then
        echo "Creating roles mapper in client scope"
        
        curl -k -s -X POST \
            -H "Authorization: Bearer $token" \
            -H "Content-Type: application/json" \
            -d '{
                "name": "root client roles",
                "protocol": "openid-connect",
                "protocolMapper": "oidc-usermodel-client-role-mapper",
                "config": {
                    "multivalued": "true",
                    "userinfo.token.claim": "true",
                    "id.token.claim": "true",
                    "access.token.claim": "true",
                    "claim.name": "roles",
                    "jsonType.label": "String"
                }
            }' \
            "$KEYCLOAK_URL/admin/realms/$REALM_NAME/client-scopes/$scope_id/protocol-mappers/models"
    else
        echo "Warning: No default client scopes found" >&2
    fi
}

# Function to create admin user
create_admin_user() {
    local token=$1
    
    echo "Creating admin user: $ISPACE_ADMIN_USERNAME"
    
    # Create user
    local res=$(curl -k -s -X POST \
        -H "Authorization: Bearer $token" \
        -H "Content-Type: application/json" \
        -d '{
            "username": "'"$ISPACE_ADMIN_USERNAME"'",
            "firstName": "'"$ISPACE_ADMIN_FIRSTNAME"'",
            "lastName": "'"$ISPACE_ADMIN_LASTNAME"'",
	    "email": "'"$ISPACE_ADMIN_EMAIL"'",
            "enabled": true,
            "emailVerified": true
        }' \
	"$KEYCLOAK_URL/admin/realms/$REALM_NAME/users"  | jq -r '.errorMessage')

    if [ -n "$res" ]; then
        echo "Error: Failed to create admin user: $res" >&2
        return 1
    fi

    local user_id=$(curl -k -s -X GET \
        -H "Authorization: Bearer $token" \
	"$KEYCLOAK_URL/admin/realms/$REALM_NAME/users" | jq -r '.[] | select(.email == "'"$ISPACE_ADMIN_EMAIL"'") | .id')

    echo "Admin user id: $user_id"
    echo "Setting admin user password"

    # Set password
    curl -k -s -X PUT \
        -H "Authorization: Bearer $token" \
        -H "Content-Type: application/json" \
        -d '{
            "type": "password",
            "value": "'"$ISPACE_ADMIN_PASSWORD"'",
            "temporary": false
        }' \
        "$KEYCLOAK_URL/admin/realms/$REALM_NAME/users/$user_id/reset-password"
 
    # Assign Admin role
    echo "Assigning Admin role to admin user"
    local client_uuid=$(curl -k -s -X GET \
        -H "Authorization: Bearer $token" \
        "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients?clientId=$CLIENT_ID" | jq -r '.[0].id')
    
    local admin_role_id=$(curl -k -s -X GET \
        -H "Authorization: Bearer $token" \
        "$KEYCLOAK_URL/admin/realms/$REALM_NAME/clients/$client_uuid/roles/Admin" | jq -r '.id')
    
    if [ -n "$admin_role_id" ] && [ "$admin_role_id" != "null" ]; then
        curl -k -s -X POST \
            -H "Authorization: Bearer $token" \
            -H "Content-Type: application/json" \
            -d '[{
                "id": "'"$admin_role_id"'",
                "name": "Admin"
            }]' \
            "$KEYCLOAK_URL/admin/realms/$REALM_NAME/users/$user_id/role-mappings/clients/$client_uuid"
    fi
    
    echo "Admin user created successfully"
}

# Main execution
echo "Starting Keycloak configuration..."
echo "Loading configuration from: $ENV_FILE and $CONFIG_FILE"


if [ ! -f "$ENV_FILE" ]; then
    echo "Error: Configuration file $ENV_FILE not found!"
    exit 1
fi

if [ ! -f "$CONFIG_FILE" ]; then
    echo "Error: Configuration file $CONFIG_FILE not found!"
    exit 1
fi

source "$ENV_FILE"
source "$CONFIG_FILE"

# Get admin token
echo "Getting admin access token..."
ADMIN_TOKEN=$(get_admin_token)

if [ -z "$ADMIN_TOKEN" ] || [ "$ADMIN_TOKEN" == "null" ]; then
    echo "Error: Failed to get admin token. Check Keycloak URL and admin credentials."
    exit 1
fi

# Check if realm exists
echo "Checking if realm '$REALM_NAME' exists..."
EXISTING_REALM=$(realm_exists "$ADMIN_TOKEN" "$REALM_NAME")

if [ -n "$EXISTING_REALM" ] && [ "$EXISTING_REALM" != "null" ]; then
    echo "Realm '$REALM_NAME' already exists. Using existing realm."
else
    # Create realm
    echo "Creating realm '$REALM_NAME'..."
    create_realm "$ADMIN_TOKEN"
    sleep 2
fi


# Get realm public key
echo "Getting realm public key..."
PUBLIC_KEY=$(get_realm_public_key "$ADMIN_TOKEN")
if [ -n "$PUBLIC_KEY" ] && [ "$PUBLIC_KEY" != "null" ]; then
    echo "Got realm Public Key (RS257)"
    # echo "-----BEGIN PUBLIC KEY-----"
    # echo "$PUBLIC_KEY" #| fold -w 64
    # echo "-----END PUBLIC KEY-----"
else
    echo "Warning: Failed to get realm public key" >&2
fi

# Create client
echo "Creating client '$CLIENT_ID'..."
CLIENT_UUID=$(get_client_uuid "$ADMIN_TOKEN")
sleep 1
if [ -n "$CLIENT_UUID" ] && [ "$CLIENT_UUID" != "null" ]; then
    echo "Found existing client $CLIENT_ID in $REALM_NAME"
else
    res=$(create_client "$ADMIN_TOKEN")
    sleep 1
    echo "		.... created with $res"
fi


# Get client secret
echo "Getting client secret..."
CLIENT_SECRET=$(get_client_secret "$ADMIN_TOKEN" "$CLIENT_ID")
if [ -n "$CLIENT_SECRET" ] && [ "$CLIENT_SECRET" != "null" ]; then
    echo "Client Secret: $CLIENT_SECRET"
    echo "Client ID: $CLIENT_ID"
else
    echo "Warning: Failed to get client secret" >&2
fi

# Create client roles
echo "Creating client roles: $CLIENT_ROLES"
create_client_roles "$ADMIN_TOKEN" "$CLIENT_ID" "$CLIENT_ROLES"
sleep 1

# Set service account roles
echo "Setting service account roles: $SERVICE_ACCOUNT_ROLES"
set_service_account_roles "$ADMIN_TOKEN" "$CLIENT_ID" "$SERVICE_ACCOUNT_ROLES"
sleep 1
echo "Setting service account roles: $SERVICE_ACCOUNT_ROLES_RM"
set_service_account_roles_rm "$ADMIN_TOKEN" "$CLIENT_ID" "$SERVICE_ACCOUNT_ROLES_RM"
sleep 1

# Set default realm role
echo "Setting default realm role: $DEFAULT_REALM_ROLE"
set_default_realm_role "$ADMIN_TOKEN" "$CLIENT_ID" "$DEFAULT_REALM_ROLE"

# Create roles mapper
echo "Creating roles mapper in client scopes..."
create_roles_mapper "$ADMIN_TOKEN"

# Create admin user
create_admin_user "$ADMIN_TOKEN"

echo "=================================================="
echo "Keycloak configuration completed successfully!"
echo "Realm: $REALM_NAME"
echo "Client ID: $CLIENT_ID"
echo "Client Secret: $CLIENT_SECRET"
echo "Public Key: $PUBLIC_KEY"
echo "Admin User: $ISPACE_ADMIN_USERNAME"
echo "=================================================="

echo "Setting KeyCloak variables in .env file"
sed -i "s/KeyCloak__Realm=.*/KeyCloak__Realm=${REALM_NAME}/" ${ENV_FILE}
sed -i "s/KeyCloak__ClientId=.*/KeyCloak__ClientId=${CLIENT_ID}/" ${ENV_FILE}
sed -i "s/KeyCloak__ClientUid=.*/KeyCloak__ClientUid=${CLIENT_UUID}/" ${ENV_FILE}
escaped_variable="${CLIENT_SECRET//\//\\/}"
sed -i "s/KeyCloak__ClientSecret=.*/KeyCloak__ClientSecret=${CLIENT_SECRET}/" ${ENV_FILE}
escaped_variable="${PUBLIC_KEY//\//\\/}"
sed -i "s/KeyCloak__PublicKeyJWT=.*/KeyCloak__PublicKeyJWT=${escaped_variable}/" ${ENV_FILE}
