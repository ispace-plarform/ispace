#!/bin/bash
#
set -e  # Выход при ошибке

source .env

# Конфигурационные переменные
MONGO_DIR="../data/mongo"
MONGO_DATA_DIR="${MONGO_DIR}/db"
MONGO_KEYFILE="./mongodb/keyfile"
MONGO_CONF_DIR="/etc/mongod.conf"
MONGO_ADMIN_USER=${MONGO_INITDB_ROOT_USERNAME}
MONGO_ADMIN_PASSWORD=${MONGO_INITDB_ROOT_PASSWORD}

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Функции логирования
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}


# Шаг 1: Создание keyFile для внутренней аутентификации
create_keyfile() {
    log_info "Создание keyFile для аутентификации mongo..."
    
    if [ -f "$MONGO_KEYFILE" ]; then
        log_warn "KeyFile уже существует, пропускаем создание"
    else
        # Создаем keyFile
        openssl rand -base64 756 > "$MONGO_KEYFILE"
        log_info "KeyFile создан: $MONGO_KEYFILE"
    fi
    
    # Устанавливаем права
    FILE_UID=$(stat -c %u "$MONGO_KEYFILE")
    FILE_GID=$(stat -c %g "$MONGO_KEYFILE")

    if [[ -r "$MONGO_KEYFILE" ]] && [ "$FILE_UID" -eq 999 ] && [ "$FILE_GID" -eq 999 ]; then
        log_info "Установлены правильные права на KeyFile: $MONGO_KEYFILE"
    else 
	log_info "Пробуем поставить правильные права, но для этого надо быть sudo"
        sudo chown 999:999 "$MONGO_KEYFILE"  # Владелец mongodb в контейнере
        sudo chmod 400 "$MONGO_KEYFILE"
        log_info "Установлены правильные права на KeyFile: $MONGO_KEYFILE"
    fi
}

initiate_replica_set() {
    local container_name=$1
    log_info "Инициализация репликасета..."
    
    # Проверяем, не инициализирован ли уже репликасет
    local replica_status=$(docker exec $container_name mongosh --quiet \
        -u "$MONGO_ADMIN_USER" \
        -p "$MONGO_ADMIN_PASSWORD" \
        --authenticationDatabase admin \
        --eval "rs.status().ok" 2>/dev/null || echo "0")
    
    if [ "$replica_status" = "1" ]; then
        log_warn "Репликасет уже инициализирован, пропускаем"
        return 0
    fi
    
    # Инициализируем репликасет
    docker exec $container_name mongosh --quiet \
        -u "$MONGO_ADMIN_USER" \
        -p "$MONGO_ADMIN_PASSWORD" \
        --authenticationDatabase admin \
        --eval "
        rs.initiate({
            _id: \"$MONGO_REPLICA_SET_NAME\",
            members: [
                { _id: 0, host: \"localhost:27017\" }
            ]
        })
    "
    
    # Ждем инициализации
    sleep 5
    
    log_info "Репликасет инициализирован"
}

# Шаг 5: Проверка статуса репликасета
check_replica_status() {
    local container_name=$1
    log_info "Проверка статуса репликасета..."
    
    docker exec $container_name mongosh \
        -u "$MONGO_ADMIN_USER" \
        -p "$MONGO_ADMIN_PASSWORD" \
        --authenticationDatabase admin \
        --eval "
        print('=== Статус репликасета ===');
        rs.status();
        print('\\n=== Конфигурация репликасета ===');
        rs.conf();
        print('\\n=== Информация о подключении ===');
        db.adminCommand({connPoolStats: 1});
    "
}

# Шаг 6: Создаем коллекции в БД
create_collections() {
    # Выполняем скрипт
    local container_name=$1
    local mongo_init_script=$2
    log_info "Создание начальных данных..."
    
    docker exec -i $container_name mongosh \
        -u $MONGO_ADMIN_USER \
        -p $MONGO_ADMIN_PASSWORD \
        --authenticationDatabase admin \
        < $mongo_init_script

    echo "✅ Коллекции созданы в MongoDB"
}

# Функция создания тестовой базы данных и пользователя
create_test_database() {
    local container_name=$1
    log_info "Создание тестовой базы данных..."
    
    docker exec $container_name mongosh \
        -u "$MONGO_ADMIN_USER" \
        -p "$MONGO_ADMIN_PASSWORD" \
        --authenticationDatabase admin \
        --eval "
        use testdb;
        db.createUser({
            user: 'testuser',
            pwd: 'testpass123',
            roles: [
                { role: 'readWrite', db: 'testdb' }
            ]
        });
        db.testcollection.insertOne({ message: 'Тестовая запись', timestamp: new Date() });
        print('Тестовая база данных создана');
    "
}

    
#check_dependencies
#create_keyfile
#initiate_replica_set "mongodb"
#check_replica_status
#create_test_database
    
#log_info "=== Настройка завершена успешно! ==="
#log_info "Данные MongoDB: $MONGO_DATA_DIR"
#log_info "KeyFile: $MONGO_KEYFILE"
#log_info "Подключение: mongosh -u $MONGO_ADMIN_USER -p ****** --authenticationDatabase admin"
#log_info "Порт: $MONGO_PORT"
