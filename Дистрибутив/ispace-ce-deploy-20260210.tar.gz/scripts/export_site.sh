#!/bin/bash

# Скрипт для экспорта коллекций MongoDB
# Использование: ./export_site.sh [OPTIONS]
# 
# Опции:
#   -s, --site SITE_ID     ID сайта для экспорта (обязательно)
#   -d, --database DB      Имя базы данных (по умолчанию: iSpaceContent)
#   -u, --user USERNAME    Имя пользователя admin
#   -p, --password PASS    Пароль admin
#   -o, --output FILE      Имя выходного файла
#   -h, --host HOST        Хост MongoDB (по умолчанию: localhost:27017)
#   --env-file FILE        Файл с переменными окружения (по умолчанию: .env)

set -e

# Значения по умолчанию
DB_NAME="iSpaceContent"
HOST="localhost:27017"
ENV_FILE=".env"
AUTH_DB="admin"
BACKUP_DIR="/data/backup/db"		# Каталог как определен в контейнере монго

echo " >>> "

# Парсинг аргументов
while [[ $# -gt 0 ]]; do
    case $1 in
        -s|--site)
            COLLECTION_FAMILY="$2"
            shift
            shift
            ;;
        -d|--database)
            DB_NAME="$2"
            shift
            shift
            ;;
        -u|--user)
            MONGO_USER="$2"
            shift
            shift
            ;;
        -p|--password)
            MONGO_PASSWORD="$2"
            shift
            shift
            ;;
        -o|--output)
            OUTPUT_FILE="$2"
            shift
            shift
            ;;
        -h|--host)
            HOST="$2"
            shift
            shift
            ;;
        --env-file)
            ENV_FILE="$2"
            shift
            shift
            ;;
        *)
            echo "Неизвестный параметр: $1"
            exit 1
            ;;
    esac
done

# Загрузка переменных из .env файла
if [[ -f "$ENV_FILE" ]]; then
    echo "Загружаем переменные из $ENV_FILE"
    set -a
    source "$ENV_FILE"
    set +a
fi

# Установка учетных данных
if [[ -z "$MONGO_USER" ]]; then
    MONGO_USER="${MONGO_INITDB_ROOT_USERNAME}"
fi

if [[ -z "$MONGO_PASSWORD" ]]; then
    MONGO_PASSWORD="${MONGO_INITDB_ROOT_PASSWORD}"
fi

# Проверка обязательных параметров
if [[ -z "$COLLECTION_FAMILY" ]]; then
    echo "Ошибка: Имя сайта обязательно"
    echo "Использование: $0 -s SITE_ID"
    exit 1
fi

if [[ -z "$MONGO_USER" || -z "$MONGO_PASSWORD" ]]; then
    echo "Ошибка: Не указаны учетные данные MongoDB"
    echo "Укажите через параметры или переменные среды MONGO_INITDB_ROOT_USERNAME/MONGO_INITDB_ROOT_PASSWORD"
    exit 1
fi

# Установка имени выходного файла
if [[ -z "$OUTPUT_FILE" ]]; then
    OUTPUT_FILE="$COLLECTION_FAMILY"
fi

FULL_OUTPUT_PATH="$BACKUP_DIR/${OUTPUT_FILE}.json"

echo "=== Экспорт коллекций MongoDB ==="
echo "База данных: $DB_NAME"
echo "Сайт: $COLLECTION_FAMILY"
echo "Хост: $HOST"
echo "Выходной файл: $FULL_OUTPUT_PATH"

# Создаем директорию для бэкапа если не существует
#mkdir -p "$BACKUP_DIR"

# Получаем список коллекций, которые начинаются с указанного семейства
echo "Поиск коллекций с префиксом: ${COLLECTION_FAMILY}."

COLLECTIONS=$(docker compose exec mongodb mongosh "mongodb://$HOST/$DB_NAME" \
    --username "$MONGO_USER" \
    --password "$MONGO_PASSWORD" \
    --authenticationDatabase "$AUTH_DB" \
    --quiet \
    --eval "db.getCollectionNames().filter(function(c) { return c.startsWith('${COLLECTION_FAMILY}.') }).join(' ')")

if [[ -z "$COLLECTIONS" ]]; then
    echo "Не найдено коллекций с префиксом: ${COLLECTION_FAMILY}."
    exit 1
fi

echo "Найдены коллекции: $COLLECTIONS"

# Экспортируем каждую коллекцию
for collection in $COLLECTIONS; do
    echo "Экспортируем коллекцию: $collection"
    
    docker compose exec mongodb mongoexport \
        --host "$HOST" \
        --db "$DB_NAME" \
        --collection "$collection" \
        --username "$MONGO_USER" \
        --password "$MONGO_PASSWORD" \
        --authenticationDatabase "$AUTH_DB" \
        --out "${BACKUP_DIR}/${collection}.json"
    
    if [[ $? -eq 0 ]]; then
        echo "✓ Успешно экспортирована: $collection"
    else
        echo "✗ Ошибка при экспорте: $collection"
        exit 1
    fi
done

# Создаем файл с информацией о экспорте
INFO_FILE="${BACKUP_DIR}/${OUTPUT_FILE}_info.txt"
cat > "$INFO_FILE" << EOF
Информация о экспорте:
Дата: $(date)
База данных: $DB_NAME
Сайт: $COLLECTION_FAMILY
Экспортированные коллекции: $COLLECTIONS
Пользователь: $MONGO_USER
Хост: $HOST
EOF

echo "=== Экспорт завершен ==="
echo "Файлы сохранены в: $BACKUP_DIR"
echo "Коллекции: $COLLECTIONS"
