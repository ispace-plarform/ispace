#!/bin/bash
# cleanup.sh - Скрипт очистки данных и логов

set -e

read -p "Вы уверены что хотите удалить ВСЕ данные iSpace? (y/N): " confirm
if [ "$confirm" != "y" ] && [ "$confirm" != "Y" ]; then
    echo "Отменено"
    exit 0
fi

read -p "Введите 'DELETE' для подтверждения: " final_confirm
if [ "$final_confirm" != "DELETE" ]; then
    echo "Отменено"
    exit 0
fi

echo "Остановка контейнеров..."
docker-compose down 2>/dev/null || true

echo "Удаление данных..."
sudo rm -rf /var/iSpace/data 2>/dev/null && echo "  ✓ Каталог data/ удален" || echo "Не удалось удалить data/ (требуются права sudo)"
sudo rm -rf /var/iSpace/logs 2>/dev/null && echo "  ✓ Каталог logs/ удален" || echo "Не удалось удалить logs/ (требуются права sudo)"

echo "Данные очищены. Конфигурационные файлы сохранены."
