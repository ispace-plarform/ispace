#!/bin/bash

# --------------------------------------------------------------------
# Load configuration
source .env

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Функции логирования
log_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }
log_step() { echo -e "${BLUE}[STEP]${NC} $1"; }


# Просим подтвердить лицензию
license_accept() {
  
    rm .license_accepted 2> /dev/null
    cat ./iSpace_EULA | more
    read -p "Продолжая установку ПО вы принимаете условия лицензии. Да? (y/n): " answer
    case ${answer:0:1} in
        y|Y )
            echo "Вы приняли лицензионное соглашение. Добро пожаловать!"
            echo "Лицензионное соглашение принято $(date) пользователем $(whoami)" >> .license_accepted
            sleep 3
            return 0
        ;;
        * )
            echo "Спасибо за попытку! Пожалуйста, удалите дистрибутив."
	    return 1
        ;;
    esac
}
    
# Определение переменных
COMPOSE_FILE="docker-compose.yml"
MAX_WAIT_TIME=60 # Максимальное время ожидания в секундах

# Функция проверки зависимостей
check_dependencies() {
    log_info "Проверка зависимостей..."

    # Проверяем что скрипт запущен с правами root/sudo
    if [ "$EUID" -ne 0 ]; then
        log_warn "Скрипт требует sudo права для некоторых операций"
    fi

    local deps=("curl" "jq" "openssl")
    for dep in "${deps[@]}"; do
        if ! command -v "$dep" &> /dev/null; then
            log_error "Необходима утилита: $dep"
            log_info "Установите: sudo apt-get install $dep"
            exit 1
        fi
    done

    log_info "Все зависимости удовлетворены"
}

# Функция для проверки запуска контейнеров
check_containers() {
    # Get the line count 
    LINE_COUNT=$(docker compose -f "$COMPOSE_FILE" ps | wc -l )

    if [[ "$LINE_COUNT" -gt 1 ]]; then
        return 0
    else
        return 1
    fi
}

# Функция для проверки готовности контейнера через healthcheck
wait_for_container_healthy() {
    local container_name=$1
    local wait_time=0

    echo "Ожидаю готовности контейнера $container_name..."

    while [ $wait_time -lt $MAX_WAIT_TIME ]; do
	    local status=$(docker compose -f "$COMPOSE_FILE" ps | grep "$container_name" | grep -o -F -w "healthy")

        if [[ "$status" == "healthy" ]]; then
            echo "Контейнер $container_name готов и healthy."
            return 0
        elif [[ "$status" == "unhealthy" ]]; then
            echo "Ошибка: Контейнер $container_name unhealthy." >&2
            return 1
        fi

        sleep 10
        wait_time=$((wait_time + 10))
        echo "Прошло $wait_time секунд."
    done

    echo "Таймаут ожидания готовности контейнера $container_name" >&2
    return 0
}

# Функция для запроса на остановку контейнеров
ask_shutdown() {
    read -p "Контейнеры запущены. Хотите остановить их и запустить заново? (y/n): " answer
    case ${answer:0:1} in
        y|Y )
            echo "Останавливаю контейнеры..."
            docker compose -f "$COMPOSE_FILE" down
            return 0
        ;;
        * )
            echo "Продолжаем с существующими контейнерами"
        ;;
    esac
}

ask_use_keycloak() {
    read -p "Вы можете использовать сервис аутентификации пользователей KeyCloak из комплекта поставки iSpace или отдельно установленный в организации. Использовать из комплекта поставки iSpace? (y/n): " answer
    case ${answer:0:1} in
        y|Y )
            return 0
        ;;
        * )
	    return 1
        ;;
    esac    
}

ask_proceed() {
    read -p "Продолжаем? (y/n): " answer
    if [ "$answer" != "y" ] && [ "$answer" != "Y" ]; then
        return 1
    fi
    return 0
}

# Функция для запуска контейнера с ожиданием его фактического запуска
start_container() {
    local container_name=$1

    echo "Запускаю контейнер $container_name..."
    docker compose -f "$COMPOSE_FILE" up -d "$container_name"

    # Ждем готовности контейнера
    if ! wait_for_container_healthy "$container_name"; then
        echo "Не удалось запустить контейнер $container_name" >&2
        exit 1
    fi
}

# Функция выполнения команд в контейнере с проверкой ошибок
exec_in_container() {
    local container="$1"
    local command="$2"
    local max_retries=3
    local retry_count=0

    while [ $retry_count -lt $max_retries ]; do
        if docker exec $container bash -c "$command"; then
            return 0
        else
            retry_count=$((retry_count + 1))
            log_info "Попытка $retry_count/$max_retries не удалась, повторяем..."
            sleep 2
        fi
    done

    log_error "Не удалось выполнить команду в контейнере $container"
    return 1
}

# Функция для выполнения скрипта
run_script() {
    local script_name=$1
    local script_args=$2

    if [[ -f "$script_name" && -x "$script_name" ]]; then
        echo "Выполняю скрипт $script_name ..."
        . "$script_name" $script_args
    else
        echo "Скрипт $script_name не найден или не исполняем. Продолжаю без него."
    fi
}

# Основная логика скрипта
echo "=== Приступаем к развертыванию платформы iSpace ==="
echo "Ознакомьтесь и примите лицензионное соглашение"
sleep 2

if ! license_accept; then
    exit 1
fi

# Проверяем наличие docker compose файла
if [[ ! -f "$COMPOSE_FILE" ]]; then
    echo "Ошибка: Файл $COMPOSE_FILE не найден!" >&2
    exit 1
fi

# Проверяем, запущены ли контейнеры
if check_containers; then
    echo "Обнаружены запущенные контейнеры"
    # Спрашиваем об остановке
    ask_shutdown
else
    echo "Контейнеры не запущены. Продолжаем..."
fi

# Проверяем, использовать существующий KeyCloak или из комплекта поставки
#if ask_use_keycloak; then
echo "Приступаем к запуску KeyCloak"

# Поднимаем postgresql
start_container "postgresql"

# Выполняем скрипт для подготовки postgresql
exec_in_container "postgresql" "PGPASSWORD=\"$POSTGRES_PASSWORD\" psql -h \"$HOST\" -p \"$POSTGRES_PORT\" -U \"$POSTGRES_USER\" << EOF
CREATE USER $POSTGRES_KEYCLOAK_USER WITH ENCRYPTED PASSWORD '$POSTGRES_KEYCLOAK_PASSWORD';
CREATE DATABASE $POSTGRES_KEYCLOAK_DB OWNER $POSTGRES_KEYCLOAK_USER;
GRANT ALL PRIVILEGES ON DATABASE $POSTGRES_KEYCLOAK_DB TO $POSTGRES_KEYCLOAK_USER;
EOF
"

log_info "PostgreSQL запущен и настроен"
if ! ask_proceed; then
   exit 0
fi
#    run_script "./scripts/postgresql_setup.sh"

# Поднимаем keycloak
start_container "keycloak"

# Выполняем скрипт для настройки keycloak
run_script "./scripts/keycloak_setup.sh"

log_info "KeyCloak запущен и настроен"
if ! ask_proceed; then
   exit 0
fi

# Выполняем скрипт для внесения изменений в скрипт создания БД с указанием администратора, созданного в KeyCloak
run_script "./scripts/mongo_add_admin.sh" "./mongodb/create-db.js $ISPACE_ADMIN_USERNAME $ISPACE_ADMIN_FIRSTNAME $ISPACE_ADMIN_LASTNAME $ISPACE_ADMIN_EMAIL $ISPACE_ADMIN_MOBILE $ISPACE_ADMIN_WORK"

# Поднимаем mongo
source scripts/mongo_setup.sh

# Выполняем подготовку к старту mongo
check_dependencies
create_keyfile

start_container "mongodb"

# Выполняем скрипты для настройки mongo
initiate_replica_set "mongodb"
check_replica_status "mongodb"

# Заполняем начальными данными
create_collections "mongodb" "./mongodb/create-db.js"

#log_info "Распаковываем демо данные из архива mongodb/Demo_Content.tar.gz"
#if [[ -f ./mongodb/Demo_Content.tar.gz ]]; then
#    tar -xzvf ./mongodb/Demo_Content.tar.gz -C /var/iSpace/data/mongo/backup
#    log_warn "Expecting the backup dir is at /var/iSpace/data/mongo/backup/"
#else
#    log_warn "Файл с демо данными не найден"
#fi
#./scripts/mongo_restore.sh 

log_info "=== Настройка mongo завершена успешно! ==="
if ! ask_proceed; then
   exit 0
fi

# Поднимаем minio
start_container "minio"

# Выполняем скрипт для настройки minio
run_script "./scripts/minio_setup.sh"

# Поднимаем всё остальное
# Подключаем функции проверки
#source ./scripts/docker-healthcheck-functions.sh

log_info "Запуск всех остальных сервисов"
docker compose -f "$COMPOSE_FILE" up -d

#echo "Ожидаем полный запуск всех сервисов"
#if check_all_services_healthy_simple "$COMPOSE_FILE" 300; then
    #echo -e "\e[32mВсе сервисы успешно запущены!\e[0m"

    # Показываем детальный отчет
    #get_services_status_report "$COMPOSE_FILE"

    # Можно выполнять дополнительные действия
    # echo "Выполняем пост-настройку..."

#else
    #echo "\e[31mНе все сервисы запустились корректно\e[0m"
    #get_services_status_report "$COMPOSE_FILE"
    #exit 1
#fi

echo "=== Базовое развертывание платформы iSpace завершено. Проверьте наличие ошибок запуска и статус запущенных контейнеров==="
exit 0
