#!/bin/bash

set -e  # Выход при ошибке

source .env

# Учетные данные
USERNAME="${ISPACE_ADMIN_USERNAME:-admin}"
PASSWORD="${ISPACE_ADMIN_PASSWORD:-admin}"
SITE_ID="${SITE_ID:-home}"

# Конфигурационные переменные
KEYCLOAK_LOGIN_URL="https://$KC_HOSTNAME:$KC_HTTPS_PORT/realms/$KeyCloak__Realm/protocol/openid-connect/token"
CLIENT_ID=$KeyCloak__ClientId
CLIENT_SECRET=$KeyCloak__ClientSecret
TIMER_JOBS_URL="$ISPACE_URL:5001/$SITE_ID/api/Timer/jobs/recurring"

# Файлы для хранения токена
TOKEN_FILE="/tmp/ispace_token.json"

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Функции логирования
log_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Функция проверки зависимостей
check_dependencies() {
    local deps=("curl" "jq")
    for dep in "${deps[@]}"; do
        if ! command -v "$dep" &> /dev/null; then
            log_error "Необходима утилита: $dep"
            log_info "Установите: sudo apt-get install $dep"
            exit 1
        fi
    done

    if [[ ! -f ".env" ]]; then
        log_error "Файл конфигурации iSpace не обнаружен. Утилита должна быть вызвана из каталога установки iSpace."
        exit 1
    fi
}

# Функция проверки токена сохраненного в файле
check_token_validity() {
    if [[ ! -f "$TOKEN_FILE" ]]; then
        return 1
    fi
    
    local token_expires=$(jq -r '.expires_in' "$TOKEN_FILE" 2>/dev/null)
    local token_time=$(jq -r '._timestamp' "$TOKEN_FILE" 2>/dev/null)
    
    if [[ -z "$token_expires" ]] || [[ -z "$token_time" ]]; then
        return 1
    fi
    
    local current_time=$(date +%s)
    local token_age=$((current_time - token_time))
    local time_remaining=$((token_expires - token_age - 60))  # 60 сек запаса
    
    if [[ $time_remaining -gt 0 ]]; then
        log_info "Токен действителен еще $time_remaining секунд"
        return 0
    else
        log_warn "Токен истек или скоро истечет"
        return 1
    fi
}

# Функция получения токена авторизации
get_auth_token() {
    log_info "Получение токена авторизации..."
    
    local login_data="grant_type=password&client_id=$CLIENT_ID&client_secret=$CLIENT_SECRET&username=$USERNAME&password=$PASSWORD"

    log_info $login_data
    log_info $KEYCLOAK_LOGIN_URL
    
    local response=$(curl -k -s -w "%{http_code}" -X POST \
        -H "Content-Type: application/x-www-form-urlencoded" \
        -d "$login_data" \
        "$KEYCLOAK_LOGIN_URL")
    
    local http_code="${response: -3}"
    local response_body="${response%???}"
    
    if [[ "$http_code" -eq 200 ]]; then
        echo "$response_body" | jq '.' > "$TOKEN_FILE"
        # Добавляем timestamp для проверки срока действия
        jq --arg timestamp "$(date +%s)" '. + {_timestamp: $timestamp|tonumber}' "$TOKEN_FILE" > "${TOKEN_FILE}.tmp"
        mv "${TOKEN_FILE}.tmp" "$TOKEN_FILE"
        
        log_info "Токен успешно получен и сохранен"
        return 0
    else
        log_error "Ошибка авторизации: HTTP $http_code"
        echo "$response_body" | jq '.' 2>/dev/null || echo "$response_body"
        return 1
    fi
}

# Функция получения access_token
get_access_token() {
    if check_token_validity; then
        jq -r '.access_token' "$TOKEN_FILE"
    else
        if get_auth_token; then
            jq -r '.access_token' "$TOKEN_FILE"
        else
            return 1
        fi
    fi
}

# Функция создания job для синхронизации пользователей из KeyCloak в iSpace
create_usersync_job() {
    local access_token=$1
    
    log_info "Создание recurring job..."
    
    local job_data=$(cat << EOF
{
    "jobId": "Conteq.iSpace.KeyCloak.Jobs.UserSynchronizationJob",
    "cronExpression": "0 20 * * *",
    "parameters": {
        "SiteId": "$SITE_ID"
    }
}
EOF
    )

    local response=$(curl -k -s -w "%{http_code}" -X POST \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer $access_token" \
        -d "$job_data" \
        "$TIMER_JOBS_URL")
    
    local http_code="${response: -3}"
    local response_body="${response%???}"
    
    if [[ "$http_code" -eq 200 ]] || [[ "$http_code" -eq 204 ]]; then
        log_info "Recurring job успешно создан!"
        echo "$response_body" | jq '.' 2>/dev/null || echo "$response_body"
        return 0
    else
        log_error "Возможно ошибка создания job: HTTP $http_code"
        echo "$response_body" | jq '.' 2>/dev/null || echo "$response_body"
        return 1
    fi
}

create_searchindex_job  () {
    local access_token=$1
    
    log_info "Создание recurring job..."
    
    local job_data=$(cat << EOF
{
    "jobId": "Conteq.iSpace.ElasticSearch.Jobs.DataUpdateJob",
    "cronExpression": "*/15 * * * *",
    "parameters": {
        "SiteId": "$SITE_ID"
    }
}
EOF
    )

    local response=$(curl -k -s -w "%{http_code}" -X POST \
        -H "Content-Type: application/json" \
        -H "Authorization: Bearer $access_token" \
        -d "$job_data" \
        "$TIMER_JOBS_URL")
    
    local http_code="${response: -3}"
    local response_body="${response%???}"
    
    if [[ "$http_code" -eq 200 ]] || [[ "$http_code" -eq 204 ]]; then
        log_info "Recurring job успешно создан!"
        echo "$response_body" | jq '.' 2>/dev/null || echo "$response_body"
        return 0
    else
        log_error "Возможно ошибка создания job: HTTP $http_code"
        echo "$response_body" | jq '.' 2>/dev/null || echo "$response_body"
        return 1
    fi


}

# Функция показа справки
show_help() {
    echo "Скрипт для создания recurring job в iSpace"
    echo ""
    echo "Использование: $0 [OPTIONS]"
    echo ""
    echo "Опции:"
    echo "  -h, --help           Показать эту справку"
    echo "  -u, --username USER  Имя пользователя (по умолчанию: admin)"
    echo "  -p, --password PASS  Пароль (по умолчанию: admin)"
    echo "  -s, --site-id ID     SiteId (по умолчанию: home)"
    echo "  --clean-token        Очистить сохраненный токен"
    echo ""
    echo "Переменные окружения:"
    echo "  BASE_URL, USERNAME, PASSWORD, SITE_ID"
    echo ""
    echo "Примеры:"
    echo "  $0"
    echo "  $0 --username admin --password secret --site-id office"
    echo "  $0 --base-url https://ispace.example.com --list"
    echo "  export USERNAME=myuser && $0"
}

# Функция очистки токена
clean_token() {
    if [[ -f "$TOKEN_FILE" ]]; then
        rm -f "$TOKEN_FILE"
        log_info "Токен очищен"
    else
        log_info "Токен не найден"
    fi
}

# Основная функция
main() {
    local list_jobs=false
    
    # Парсинг аргументов командной строки
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                show_help
                exit 0
                ;;
            -u|--username)
                USERNAME="$2"
                shift 2
                ;;
            -p|--password)
                PASSWORD="$2"
                shift 2
                ;;
            -s|--site-id)
                SITE_ID="$2"
                shift 2
                ;;
            --clean-token)
                clean_token
                exit 0
                ;;
            *)
                log_error "Неизвестный параметр: $1"
                show_help
                exit 1
                ;;
        esac
    done
    
    # Проверка зависимостей
    check_dependencies
    
    log_info "=== Создание Recurring Job ==="
    log_info "URL: $BASE_URL"
    log_info "Пользователь: $USERNAME"
    log_info "SiteId: $SITE_ID"
    echo
    
    # Получение токена
    local access_token
    if get_auth_token; then
        access_token=$(jq -r '.access_token' "$TOKEN_FILE")
    else
        log_error "Не удалось получить токен"
        exit 1
    fi
    
    if [[ -z "$access_token" ]]; then
        log_error "Не удалось получить access token"
        exit 1
    fi

    # Создание job
    log_info "Приступаем к созданию задания по синхронизации пользователей"
    if create_usersync_job "$access_token"; then
        log_info "=== Job успешно создан ==="
        log_info "Job ID: Conteq.iSpace.KeyCloak.Jobs.UserSynchronizationJob"
        log_info "Cron: 0 20 * * * (ежедневно в 20:00)"
        log_info "Parameters: { SiteId: $SITE_ID }"
    else
        log_error "=== Ошибка создания job ==="
        exit 1
    fi

    # Создание job
    log_info "Приступаем к созданию задания по индексации поиска"
    if create_searchindex_job "$access_token"; then
        log_info "=== Job успешно создан ==="
        log_info "Job ID: Conteq.iSpace.ElasticSearch.Jobs.DataUpdateJob"
	log_info "Cron: */15 * * * * (каждые 15 минут)"
        log_info "Parameters: { SiteId: $SITE_ID }"
    else
        log_error "=== Ошибка создания job ==="
        exit 1
    fi
}

# Запуск основной функции
main "$@"
