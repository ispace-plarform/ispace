#!/bin/bash
#
# Скрипт полностью переписывает блок создания пользователей:
# удаляет всех пользователей кроме system, и добавляет нового пользователя с заданными параметрами (администратор)
#
# Предназначен для вызова при инициализации системы после создания администратора в KeyCloak
#

# Параметры для нового пользователя
FILE="${1:-mongodb/create-db.js}"
LOGIN_NAME="${2:-admin}"
FIRST_NAME="${3:-iSpace}"
LAST_NAME="${4:-Admin}"
EMAIL="${5:-admin@ispace.ru}"
MOBILE_PHONE="${6:-+78524589655}"
WORK_PHONE="${7:-+788556698547}"

# Создаем временный файл
TEMP_FILE=$(mktemp)

# Формируем новую запись о пользователях
NEW_BLOCK="db.ACM_Users.insertMany([{
  \"SourceId\": null,
  \"LoginName\": \"$LOGIN_NAME\",
  \"FirstName\": \"$FIRST_NAME\",
  \"LastName\": \"$LAST_NAME\",
  \"Name\": \"$LAST_NAME $FIRST_NAME\",
  \"Email\": \"$EMAIL\",
  \"MobilePhone\": \"$MOBILE_PHONE\",
  \"WorkPhone\": \"$WORK_PHONE\",
  \"Groups\": [members.insertedId, owners.insertedId],
  \"IsLocked\": false,
  \"SystemRole\": 3,
  \"PrincipalType\": 1,
  \"SiteIds\": [\"home\"]
},
{
  \"SourceId\": null,
  \"LoginName\": \"s|system#\",
  \"FirstName\": \"\",
  \"LastName\": \"\",
  \"Name\": \"Система\",
  \"Email\": \"\",
  \"MobilePhone\": \"\",
  \"WorkPhone\": \"\",
  \"Groups\": [],
  \"IsLocked\": false,
  \"SystemRole\": 3,
  \"PrincipalType\": 1
}]);"

# Используем awk для замены
awk -v new_block="$NEW_BLOCK" '
    /db\.ACM_Users\.insertMany/ {
        print new_block
        skip = 1
        next
    }
    skip && /\]\);$/ {
        skip = 0
        next
    }
    skip { next }
    { print }
    ' "$FILE" > "$TEMP_FILE"

# Заменяем файл
mv "$TEMP_FILE" "$FILE"
echo "✅ В скрипте создания инициализации БД mongo задан администратор: $LAST_NAME $FIRST_NAME ($LOGIN_NAME)"
