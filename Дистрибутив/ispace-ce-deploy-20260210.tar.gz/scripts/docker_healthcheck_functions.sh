#!/bin/bash

# Функция проверки, что все сервисы в docker-compose успешно поднялись
check_all_services_healthy() {
    local compose_file=${1:-"docker-compose.yml"}
    local max_wait_time=${2:-300}
    local wait_time=0
    
    echo "Проверяем состояние всех сервисов в docker-compose..."
    
    while [ $wait_time -lt $max_wait_time ]; do
        # Получаем статусы всех сервисов
        local services_status=$(docker-compose -f "$compose_file" ps --format json | jq -r '.[] | "\(.Service),\(.State),\(.Status)"' 2>/dev/null)
        
        if [ $? -ne 0 ]; then
            # Если jq не доступен, используем альтернативный метод
            services_status=$(docker-compose -f "$compose_file" ps | tail -n +3 | awk '{print $1 "," $4}')
        fi
        
        local all_healthy=true
        local has_unhealthy=false
        
        # Проверяем статус каждого сервиса
        while IFS= read -r line; do
            if [ -n "$line" ]; then
                local service=$(echo "$line" | cut -d',' -f1)
                local status=$(echo "$line" | cut -d',' -f2)
                
                echo "Сервис $service: $status"
                
                if [[ "$status" != "running" && "$status" != "healthy" ]]; then
                    all_healthy=false
                    if [[ "$status" == "unhealthy" || "$status" == "exited" ]]; then
                        has_unhealthy=true
                    fi
                fi
            fi
        done <<< "$services_status"
        
        if $all_healthy; then
            echo "✅ Все сервисы успешно запущены и здоровы!"
            return 0
        fi
        
        if $has_unhealthy; then
            echo "❌ Обнаружены нездоровые сервисы. Прерываем ожидание."
            return 1
        fi
        
        sleep 5
        wait_time=$((wait_time + 5))
        echo "Ожидаем... Прошло $wait_time секунд из $max_wait_time"
    done
    
    echo "⏰ Таймаут ожидания запуска всех сервисов"
    return 1
}

# Альтернативная версия с использованием docker-compose ps
check_all_services_healthy_simple() {
    local compose_file=${1:-"docker-compose.yml"}
    local max_wait_time=${2:-300}
    local wait_time=0
    
    echo "Проверяем состояние всех сервисов..."
    
    while [ $wait_time -lt $max_wait_time ]; do
        # Проверяем, что все контейнеры в статусе "Up" и не "unhealthy"
        local unhealthy_count=$(docker-compose -f "$compose_file" ps | grep -E "(unhealthy|exited|Restarting)" | wc -l)
        local total_count=$(docker-compose -f "$compose_file" ps | grep -E "^(\\w+\\-)+" | wc -l)
        local healthy_count=$(docker-compose -f "$compose_file" ps | grep -E "Up.*(healthy|\\-\\-)" | wc -l)
        
        echo "Всего сервисов: $total_count, здоровых: $healthy_count, проблемных: $unhealthy_count"
        
        if [ $unhealthy_count -gt 0 ]; then
            echo "❌ Обнаружены проблемные сервисы:"
            docker-compose -f "$compose_file" ps | grep -E "(unhealthy|exited|Restarting)"
            return 1
        fi
        
        if [ $healthy_count -eq $total_count ] && [ $total_count -gt 0 ]; then
            echo "✅ Все $total_count сервисов успешно запущены!"
            return 0
        fi
        
        sleep 5
        wait_time=$((wait_time + 5))
        echo "Ожидаем... Прошло $wait_time секунд из $max_wait_time"
    done
    
    echo "⏰ Таймаут ожидания запуска всех сервисов"
    return 1
}

# Функция для детального отчета о состоянии сервисов
get_services_status_report() {
    local compose_file=${1:-"docker-compose.yml"}
    
    echo "📊 Детальный отчет о состоянии сервисов:"
    echo "========================================"
    
    docker-compose -f "$compose_file" ps
    
    echo ""
    echo "🔍 Проверка healthcheck статусов:"
    echo "================================="
    
    # Попытка получить JSON статусы если доступен jq
    if command -v jq &> /dev/null; then
        docker-compose -f "$compose_file" ps --format json | jq -r '.[] | "\(.Service): \(.State) - \(.Status)"'
    else
        docker-compose -f "$compose_file" ps | tail -n +3 | while read line; do
            echo "$line"
        done
    fi
}

# Функция проверки конкретных сервисов
check_specific_services() {
    local compose_file=${1:-"docker-compose.yml"}
    local services=("${@:2}")
    local max_wait_time=${3:-120}
    
    if [ ${#services[@]} -eq 0 ]; then
        echo "❌ Не указаны сервисы для проверки"
        return 1
    fi
    
    for service in "${services[@]}"; do
        echo "🔍 Проверяем сервис: $service"
        if ! check_service_healthy "$compose_file" "$service" "$max_wait_time"; then
            echo "❌ Сервис $service не запустился корректно"
            return 1
        fi
    done
    
    echo "✅ Все указанные сервисы успешно запущены!"
    return 0
}

# Функция проверки одного сервиса
check_service_healthy() {
    local compose_file=${1:-"docker-compose.yml"}
    local service_name=$2
    local max_wait_time=${3:-120}
    local wait_time=0
    
    while [ $wait_time -lt $max_wait_time ]; do
        local status=$(docker-compose -f "$compose_file" ps --format json | jq -r ".[] | select(.Service==\"$service_name\") | .State" 2>/dev/null)
        
        if [ $? -ne 0 ]; then
            status=$(docker-compose -f "$compose_file" ps | grep "$service_name" | awk '{print $4}')
        fi
        
        if [[ "$status" == "healthy" || "$status" == "running" ]]; then
            echo "✅ Сервис $service_name: $status"
            return 0
        elif [[ "$status" == "unhealthy" || "$status" == "exited" ]]; then
            echo "❌ Сервис $service_name: $status"
            return 1
        fi
        
        sleep 3
        wait_time=$((wait_time + 3))
    done
    
    echo "⏰ Таймаут ожидания сервиса $service_name"
    return 1
}
