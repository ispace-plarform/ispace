#!/bin/bash
#
# скрипт для создания БД Keycloak
# --------------------------------------------------------------------
# Load configuration
source .env

set -e

# Параметры 
HOST="localhost"

echo "Создаем пользователя и БД для Keycloak..."

# Ожидаем доступность PostgreSQL
until PGPASSWORD="$POSTGRES_PASSWORD" psql -h "$HOST" -p "$POSTGRES_PORT" -U "$POSTGRES_USER" -c '\q' 2>/dev/null; do
    echo "⏳ Ожидаем PostgreSQL..."
    sleep 2
done

# Выполняем SQL команды
PGPASSWORD="$POSTGRES_PASSWORD" psql -h "$HOST" -p "$POSTGRES_PORT" -U "$POSTGRES_USER" << EOF
CREATE USER $POSTGRES_KEYCLOAK_USER WITH ENCRYPTED PASSWORD '$POSTGRES_KEYCLOAK_PASSWORD';
CREATE DATABASE $POSTGRES_KEYCLOAK_DB OWNER $POSTGRES_KEYCLOAK_USER;
GRANT ALL PRIVILEGES ON DATABASE $POSTGRES_KEYCLOAK_DB TO $POSTGRES_KEYCLOAK_USER;
EOF

echo "База данных Keycloak создана успешно!"
