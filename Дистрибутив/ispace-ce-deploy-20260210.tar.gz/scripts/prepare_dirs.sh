#!/bin/bash

set -e  # Выход при ошибке

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Функции логирования
log_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }
log_step() { echo -e "${BLUE}[STEP]${NC} $1"; }

# Базовые пути
BASE_DIR="/var/iSpace"
DOCKER_DIR="${BASE_DIR}/docker"

# Каталоги для данных Docker (томы)
DATA_DIRECTORIES=(
    "${BASE_DIR}/data/postgresql"
    "${BASE_DIR}/data/keycloak" 
    "${BASE_DIR}/data/mongo/db"
    "${BASE_DIR}/data/mongo/configdb"
    "${BASE_DIR}/data/mongo/backup"
    "${BASE_DIR}/data/minio"
    "${BASE_DIR}/data/rabbitmq"
    "${BASE_DIR}/data/elasticsearch"
    "${BASE_DIR}/data/redis"
)

# Каталоги для логов
LOG_DIRECTORIES=(
    "${BASE_DIR}/logs/client"
    "${BASE_DIR}/logs/platform"
    "${BASE_DIR}/logs/rabbitmq"
    "${BASE_DIR}/logs/minio"
    "${BASE_DIR}/logs/officeservice"
    "${BASE_DIR}/logs/extractor/collector"
    "${BASE_DIR}/logs/extractor/handler"
)

# Каталоги для конфигурации Docker
DOCKER_CONFIG_DIRECTORIES=(
    "${DOCKER_DIR}/scripts"
    "${DOCKER_DIR}/certs"
    "${DOCKER_DIR}/mongodb"
    "${DOCKER_DIR}/client"
    "${DOCKER_DIR}/platform"
    "${DOCKER_DIR}/officeservice"
    "${DOCKER_DIR}/collabora"
    "${DOCKER_DIR}/extractor"
    "${DOCKER_DIR}/redis"
)

# Права доступа
DATA_PERMISSIONS="755"    # rwxr-xr-x
LOG_PERMISSIONS="755"     # rwxr-xr-x
CONFIG_PERMISSIONS="755"  # rwxr-xr-x

# Функция создания каталогов
create_directories() {
    local dirs=("$@")
    local permissions=$1
    shift
    local dirs=("$@")
    
    for dir in "${dirs[@]}"; do
        if [ ! -d "$dir" ]; then
            if mkdir -p "$dir"; then
                if chmod "$permissions" "$dir"; then
                    echo "  ✓ $dir"
                else
                    log_error "Ошибка установки прав для: $dir"
                fi
            else
                log_error "Ошибка создания: $dir"
            fi
        else
            echo "  ✓ $dir (уже существует)"
        fi
    done
}

# Функция установки владельца для данных (если нужно)
set_ownership() {
    log_step "Настройка владельца для каталогов данных..."
    
    # Для PostgreSQL (UID 999 в контейнере)
    if [ -d "${BASE_DIR}/data/postgresql" ]; then
        sudo chown -R 999:999 "${BASE_DIR}/data/postgresql" 2>/dev/null && echo "  ✓ Владелец для PostgreSQL" || log_warn "Не удалось изменить владельца PostgreSQL (требуются права sudo)"
    fi
    
    # Для MongoDB (UID 999 в контейнере)
    if [ -d "${BASE_DIR}/data/mongo" ]; then
        sudo chown -R 999:999 "${BASE_DIR}/data/mongo" 2>/dev/null && echo "  ✓ Владелец для MongoDB" || log_warn "Не удалось изменить владельца MongoDB (требуются права sudo)"
    fi
}


# Функция показа справки
show_help() {
    echo "Скрипт подготовки каталогов для iSpace platform"
    echo ""
    echo "Использование: $0 [OPTION]"
    echo ""
    echo "Опции:"
    echo "  -h, --help     Показать эту справку"
    echo "  -q, --quiet    Тихий режим (только ошибки)"
    echo "  Без опций      Создать каталоги"
    echo ""
    echo "Примеры:"
    echo "  $0              # Создать каталоги"
    echo "  $0 --clean      # Очистить все данные"
    echo "  $0 --quiet      # Тихий режим создания"
}

# Функция проверки прав
check_privileges() {
    if [ "$EUID" -ne 0 ] && [ "$1" = "need_root" ]; then
        log_error "Для этой операции требуются права root/sudo"
        exit 1
    fi
}

# Основная функция создания каталогов
main_setup() {
    log_step "Подготовка каталогов для iSpace platform..."
    echo
    
    log_step "Создание каталогов данных..."
    create_directories "$DATA_PERMISSIONS" "${DATA_DIRECTORIES[@]}"
    
    log_step "Создание каталогов логов..."
    create_directories "$LOG_PERMISSIONS" "${LOG_DIRECTORIES[@]}"
    
    log_step "Создание каталогов конфигурации Docker..."
    create_directories "$CONFIG_PERMISSIONS" "${DOCKER_CONFIG_DIRECTORIES[@]}"
    
    set_ownership
    
    echo
    log_info "=== Структура каталогов создана ==="
    log_info "Данные:    ${BASE_DIR}/data/"
    log_info "Логи:      ${BASE_DIR}/logs/" 
    log_info "Конфиги:   ${DOCKER_DIR}/"
    echo
}

# Обработка аргументов командной строки
QUIET_MODE=false

case "${1:-}" in
    -h|--help)
        show_help
        exit 0
        ;;
    -q|--quiet)
        QUIET_MODE=true
        main_setup > /dev/null
        log_info "Каталоги созданы в тихом режиме"
        exit 0
        ;;
    "")
        main_setup
        exit 0
        ;;
    *)
        log_error "Неизвестная опция: $1"
        echo
        show_help
        exit 1
        ;;
esac
