#!/bin/bash
#
#!/bin/bash

set -e  # Выход при ошибке

source .env

# Конфигурационные переменные
MINIO_ACCESS_KEY="${MINIO_ACCESS_KEY:-minioadmin}"
MINIO_SECRET_KEY="${MINIO_SECRET_KEY:-minioadmin}"

# Директория для хранения конфигурации minio client
DIR_NAME=".mc"
# TODO заменить название контейнера на переменную
MC_CMD="docker run --rm -v $(pwd)/${DIR_NAME}:/root/.mc --network container:minio2 minio/mc"

MAX_WAIT_TIME=60
WAIT_INTERVAL=5

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Функции логирования
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Функция проверки зависимостей
check_dependencies() {
    log_info "Проверка зависимостей..."
    
    if ! command -v mc &> /dev/null; then
        log_warn "MinIO Client (mc) не установлен, устанавливаем..."
        install_mc_client
    fi
    
    log_info "Все зависимости удовлетворены"
}

# Функция установки MinIO Client
install_mc_client() {
    if command -v wget &> /dev/null; then
        wget https://dl.min.io/client/mc/release/linux-amd64/mc -O /usr/local/bin/mc
    elif command -v curl &> /dev/null; then
        curl https://dl.min.io/client/mc/release/linux-amd64/mc -o /usr/local/bin/mc
    else
        log_error "Не установлены wget или curl для загрузки mc"
        exit 1
    fi
    
    chmod +x /usr/local/bin/mc
    log_info "MinIO Client установлен"
}

# Функция настройки MinIO Client
setup_mc_client() {
    log_info "Настройка MinIO Client..."
    
    # Удаляем существующую конфигурацию если есть
    log_info "Удаляем существующую конфигурацию если есть"
    eval "$MC_CMD alias remove minio-local > /dev/null 2>&1 || true"
    
    # Добавляем хост MinIO
    log_info "Добавляем хост MinIO"
    eval "$MC_CMD alias set minio-local $MINIO_SERVER_URL $MINIO_ROOT_USER $MINIO_ROOT_PASSWORD"

    # Проверяем подключение
    if eval "$MC_CMD admin info minio-local > /dev/null 2>&1"; then
        log_info "MinIO Client настроен успешно"
        return 0
    else
        log_error "Ошибка настройки MinIO Client"
        return 1
    fi
}

# Функция проверки существования bucket
check_bucket_exists() {
    if eval "$MC_CMD ls minio-local/$MINIO_BUCKET > /dev/null 2>&1"; then
        return 0  # Bucket существует
    else
        return 1  # Bucket не существует
    fi
}

# Функция создания bucket
create_bucket() {
    log_info "Создание bucket: $MINIO_BUCKET"
    
    if check_bucket_exists; then
        log_warn "Bucket $MINIO_BUCKET уже существует"
        return 0
    fi
    
    if eval "$MC_CMD mb minio-local/$MINIO_BUCKET"; then
        log_info "Bucket $MINIO_BUCKET создан успешно"
        return 0
    else
        log_error "Ошибка создания bucket $MINIO_BUCKET"
        return 1
    fi
}

# Функция включения версионности
enable_versioning() {
    log_info "Включение версионности для bucket: $MINIO_BUCKET"
    
    # Включаем версионность
    if eval "$MC_CMD version enable minio-local/$MINIO_BUCKET"; then
        log_info "Версионность включена для bucket $MINIO_BUCKET"
        
        # Проверяем статус версионности
        local version_status=$(eval "$MC_CMD version info minio-local/$MINIO_BUCKET" 2>/dev/null | grep -i "versioning" || echo "Disabled")
        
        if echo "$version_status" | grep -qi "enabled"; then
            log_info "✅ Версионность активна"
        else
            log_warn "⚠️  Статус версионности не подтвержден"
        fi
        
        return 0
    else
        log_error "Ошибка включения версионности"
        return 1
    fi
}

# Функция настройки политик bucket
configure_bucket_policies() {
    log_info "Настройка политик для bucket: $MINIO_BUCKET"
    
    # Устанавливаем политику доступа (публичный доступ на чтение)
#    mc anonymous set download minio-local/$MINIO_BUCKET || true
    
    # Альтернативно: устанавливаем кастомную политику
#    cat > /tmp/bucket-policy.json << EOF
#{
#    "Version": "2012-10-17",
#    "Statement": [
#        {
#            "Effect": "Allow",
#            "Principal": "*",
#            "Action": [
#                "s3:GetObject",
#                "s3:GetObjectVersion"
#            ],
#            "Resource": [
#                "arn:aws:s3:::${MINIO_BUCKET}/*"
#            ]
#        }
#    ]
#}
#EOF
#    
#    mc anonymous set-json /tmp/bucket-policy.json minio-local/$MINIO_BUCKET || true
    log_info "Политики bucket настроены"
}

# Функция создания тестовых данных
create_test_data() {
    log_info "Создание тестовых данных..."
    
    # Создаем тестовый файл
    echo "Тестовый файл для проверки версионности MinIO" > /tmp/test-file.txt
    date >> /tmp/test-file.txt
    
    # Загружаем файл в bucket
    if mc cp /tmp/test-file.txt minio-local/$MINIO_BUCKET/; then
        log_info "Тестовый файл загружен"
        
        # Перезаписываем файл для создания версии
        echo "Обновленная версия файла" > /tmp/test-file.txt
        date >> /tmp/test-file.txt
        mc cp /tmp/test-file.txt minio-local/$MINIO_BUCKET/
        log_info "Вторая версия файла загружена"
    else
        log_warn "Не удалось загрузить тестовый файл"
    fi
}

# Функция проверки настройки
verify_setup() {
    log_info "Проверка настройки MinIO..."
    
    echo "=== Информация о MinIO ==="
    eval "$MC_CMD admin info minio-local"
    
    echo -e "\n=== Список bucket ==="
    eval "$MC_CMD ls minio-local/"
    
    echo -e "\n=== Статус версионности ==="
    eval "$MC_CMD version info minio-local/$MINIO_BUCKET" 2>/dev/null || echo "Версионность не доступна"
    
#    echo -e "\n=== Содержимое bucket ==="
#    mc ls minio-local/$MINIO_BUCKET/ || true
    
#    echo -e "\n=== История версий тестового файла ==="
#    mc ls minio-local/$MINIO_BUCKET/test-file.txt --versions 2>/dev/null || true
}

log_info "=== Начало настройки MinIO ==="
#check_dependencies

# Проверяем, существует ли директория
#if [ -d "$DIR_NAME" ]; then
#  rm -rf "$DIR_NAME"
#fi
# Создаем директорию (и её родительские, если они отсутствуют)
#mkdir -p "$DIR_NAME"

setup_mc_client
create_bucket
enable_versioning
configure_bucket_policies
verify_setup
