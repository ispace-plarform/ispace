#!/bin/bash

source .env

MONGO_INITDB_ROOT_USERNAME=${MONGO_INITDB_ROOT_USERNAME:-"admin"}
MONGO_INITDB_ROOT_PASSWORD=${MONGO_INITDB_ROOT_PASSWORD:-"admin"}

# Устанавливаем параметры подключения к базе данных MongoDB
CONTAINER_NAME="mongodb"
BACKUP_DIR="/data/backup/db"   					# каталог для бэкапа в контейнере
LOCAL_BACKUP_DIR="/var/iSpace/data/mongo/backup"		# локальный каталог как указано в docker-compose

DB_NAME=${DB_NAME:-""}

DATE=$(date '+%Y%m%d')

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Функции логирования
log_info() { echo -e "${GREEN}[INFO]${NC} $DATE: $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $DATE: $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $DATE: $1"; }

 
#Старт логирования
log_info "Starting MongoDB backup in container: $CONTAINER_NAME"
log_info "Target backup folder inside container: $BACKUP_DIR"

if [[ -d $LOCAL_BACKUP_DIR/$DATE ]]; then
   log_warn "Каталон $LOCAL_BACKUP_DIR/$DATE существует. Надо удалить!"
   sudo rm -rf $LOCAL_BACKUP_DIR/$DATE
fi

# Команда для создания резервной копии
if [[ ! -z $DB_NAME ]]; then
    BACKUP_DB="--db $DB_NAME"
fi

docker compose exec $CONTAINER_NAME mongodump --username $MONGO_INITDB_ROOT_USERNAME --password $MONGO_INITDB_ROOT_PASSWORD --authenticationDatabase admin $BACKUP_DB --out $BACKUP_DIR/$DATE
 
# Проверка на успешность создания резервной копии
if [ $? -eq 0 ]; then
    log_info "Резервная копия успешно создана: $BACKUP_FILE"
else
    log_error "Ошибка при создании резервной копии."
exit 1
fi
 
# Сжатие резервной копии
log_info "===> Сжатие резервной копии"
if [[ -z $DB_NAME ]]; then
    DB_NAME="All"
fi
tar -zcvf ${DB_NAME}_${DATE}.tar.gz -C $LOCAL_BACKUP_DIR .
 
 
#Окончание логирования
log_info "MONGO BACKUP COMPLETE"
log_info "Бэкап MongoDB iSpace доступен ${DB_NAME}_${DATE}.tar.gz"
log_info "==================================================================="

