#!/bin/bash

source .env

MONGO_INITDB_ROOT_USERNAME=${MONGO_INITDB_ROOT_USERNAME:-"admin"}
MONGO_INITDB_ROOT_PASSWORD=${MONGO_INITDB_ROOT_PASSWORD:-"admin"}

# Устанавливаем параметры подключения к базе данных MongoDB
CONTAINER_NAME="mongodb"
BACKUP_DIR="/data/backup/db"                                    # каталог для бэкапа в контейнере
LOCAL_BACKUP_DIR="/var/iSpace/data/mongo/backup"                # локальный каталог как указано в docker-compose

DB_NAME=${DB_NAME:-"iSpaceContent"}

DATE=$(date '+%Y%m%d')

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Функции логирования
log_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

#Старт логирования
log_info "Starting MongoDB backup restore in container: $CONTAINER_NAME"

# Выводим доступные папки с бэкапами
log_info "Доступные бэкапы:"
docker compose exec "$CONTAINER_NAME" ls -1 "$BACKUP_DIR" | grep -E '^[0-9]{8}$'

# Запрос имени папки (даты) с бэкапом
read -p "Введите дату бэкапа для восстановления (к примеру, 20250917): " BACKUP_DATE

# Проверяем наличие указанной папки
if ! docker compose exec "$CONTAINER_NAME" test -d "$BACKUP_DIR/$BACKUP_DATE"; then
    log_error " Указанная папка с бэкапом не найдена: $BACKUP_DATE"
    exit 1
fi

# Выводим доступные базы
log_info "Доступные базы для восстановления: "
docker compose exec "$CONTAINER_NAME" ls -1 "$BACKUP_DIR/$BACKUP_DATE" 

# Запрашиваем имя БД, которую нужно восстановить
read -p "Введите имя базы данных для восстановления: " DB_NAME

# Проверяем наличие указанной базы
if ! docker compose exec "$CONTAINER_NAME" test -d "$BACKUP_DIR/$BACKUP_DATE/$DB_NAME"; then
    log_error " Указанная папка с бэкапом не найдена: $DB_NAME"
    exit 1
fi


# Команда для восстановления резервной копии
docker compose exec "$CONTAINER_NAME"  mongorestore --username ${MONGO_INITDB_ROOT_USERNAME} --password ${MONGO_INITDB_ROOT_PASSWORD} --authenticationDatabase admin --drop --nsInclude=${DB_NAME}.* ${BACKUP_DIR}/${BACKUP_DATE}

# Проверка результата
if [ $? -eq 0 ]; then
    log_info " Успешно восстановлена база '$DB_NAME' из '$BACKUP_DIR/$BACKUP_DATE'"
else
    log_error " Ошибка при восстановлении базы '$DB_NAME' из '$BACKUP_DIR/$BACKUP_DATE'"
    exit 1
fi

#Окончание логирования
log_info "Восстановление базы данных $DB_NAME от $BACKUP_DATE выполнено"
log_info "==================================================================="


