// Переключаемся на admin
db = db.getSiblingDB('admin');

// Авторизация с помощью root-пользователя (напр., MONGO_INITDB_ROOT_USERNAME)
db.auth(
  process.env.MONGO_INITDB_ROOT_USERNAME,
  process.env.MONGO_INITDB_ROOT_PASSWORD
);

print("✅ Авторизация прошла успешно");



/*============ Create  iSpaceTimer database ============*/
const database = 'iSpaceContent';

use(database);

/*============ Common Collections ============*/
db.createCollection('ACM_Users')
db.createCollection('ACM_PermissionLevels')
db.createCollection('DsFieldTypes')
db.createCollection('DsWorkingCalendar')
db.createCollection('DsNotifySettings')
db.createCollection('DsSites')

/*============ OrgChart ============*/
db.createCollection('OrgChart_JobTitles')
db.createCollection('OrgChart_Departments')
db.createCollection('OrgChart_Positions')
db.createCollection('OrgChart_Deputies')
db.createCollection('OrgChart_Teams')
db.createCollection('OrgChart_TeamMembers')

/*============ Site Collections ============*/
db.createCollection('home.ACM_PermissionAssignments')
db.createCollection('home.ACM_VerificationCodes')
db.createCollection('home.DsContentTypes')
db.createCollection('home.DsContentTypeDocumentTemplates')
db.createCollection('home.DsDocumentStates')
db.createCollection('home.DsFields')
db.createCollection('home.DsLists')
db.createCollection('home.DsNavigationMenu')
db.createCollection('home.DsFavorites')
db.createCollection('home.DsViews')
db.createCollection('home.DsRoles')
db.createCollection('home.DsCounters')
db.createCollection('home.DsNotificationTemplates')
db.createCollection('home.DsPrintFormTemplates')
db.createCollection('home.DsAttachments')
db.createCollection('home.DsAttachmentMetadataSettings')
db.createCollection('home.DsAttachmentTypes')
db.createCollection('home.DsDiscussions')
db.createCollection('home.DsRecycleBin')
db.createCollection('home.DsLinks')
db.createCollection('home.DsLinkTypes')
db.createCollection('home.DsPages')
db.createCollection('home.DsTasks')
db.createCollection('home.DsRouteInstances')
db.createCollection('home.DsRouteTemplates')

homeSite = ({'_id':'home', 'DisplayName':'Home', 'HomePage':'', 'DefaultWorkspacePath':'', 'RecycleBinStoragePeriodInDays':30});
db.DsSites.insertOne(homeSite);

members = db.ACM_Users.insertOne({'Name':'Участники', 'PrincipalType':2, 'SiteId':homeSite._id})
owners = db.ACM_Users.insertOne({'Name':'Владельцы', 'PrincipalType':2, 'SiteId':homeSite._id})
visitors = db.ACM_Users.insertOne({'Name':'Посетители', 'PrincipalType':2, 'SiteId':homeSite._id})

db.ACM_Users.insertMany([{
  "SourceId": null,
  "LoginName": "admin",
  "FirstName": "System",
  "LastName": "Administrator",
  "Name": "Administrator System",
  "Email": "admin@example.com",
  "MobilePhone": "+78000101001",
  "WorkPhone": "+78000101001",
  "Groups": [members.insertedId, owners.insertedId],
  "IsLocked": false,
  "SystemRole": 3,
  "PrincipalType": 1,
  "SiteIds": ["home"]
},
{
  "SourceId": null,
  "LoginName": "s|system#",
  "FirstName": "",
  "LastName": "",
  "Name": "Система",
  "Email": "",
  "MobilePhone": "",
  "WorkPhone": "",
  "Groups": [],
  "IsLocked": false,
  "SystemRole": 3,
  "PrincipalType": 1
}]);

reader = db.ACM_PermissionLevels.insertOne({'Name':'Чтение', 'SystemLevel':true, 'Description':'', 'Permissions':[103, 106]})
editor = db.ACM_PermissionLevels.insertOne({'Name':'Изменение', 'SystemLevel':true, 'Description':'', 'Permissions':[100, 102, 103, 104, 105, 106]})
fullControl = db.ACM_PermissionLevels.insertOne({'Name':'Полный доступ', 'SystemLevel':true, 'Description':'', 'Permissions':[100, 101, 102, 103, 104, 105, 106, 107, 108, 109]})

db.home.ACM_PermissionAssignments.insertOne({'SecureObjectId':'home', 'AssignmentsCollection':[{'PrincipalId':members.insertedId, 'PermissionLevels':[editor.insertedId]}, {'PrincipalId':owners.insertedId, 'PermissionLevels':[fullControl.insertedId]}, {'PrincipalId':visitors.insertedId, 'PermissionLevels':[reader.insertedId]}]});

urlFT = db.DsFieldTypes.insertOne({'Name':'URL', 'DisplayName':'Гиперссылка'})
userFT = db.DsFieldTypes.insertOne({'Name':'User', 'DisplayName':'Пользователь или группа'})
lookupFT = db.DsFieldTypes.insertOne({'Name':'Lookup', 'DisplayName':'Подстановка'})
textFT = db.DsFieldTypes.insertOne({'Name':'Text', 'DisplayName':'Однострочный текст'})
choiceFT = db.DsFieldTypes.insertOne({'Name':'Choice', 'DisplayName':'Выбор'})
boolFT = db.DsFieldTypes.insertOne({'Name':'Boolean', 'DisplayName':'Да/Нет'})
numberFT = db.DsFieldTypes.insertOne({'Name':'Number', 'DisplayName':'Число'})
noteFT = db.DsFieldTypes.insertOne({'Name':'Note', 'DisplayName':'Многострочный текст'})
dateFT = db.DsFieldTypes.insertOne({'Name':'DateTime', 'DisplayName':'Дата и время'})
docStateFT = db.DsFieldTypes.insertOne({'Name':'DocumentState', 'DisplayName':'Подстановка на Состояния документов'})
parentLinkFT = db.DsFieldTypes.insertOne({'Name':'ParentLink', 'DisplayName':'Ссылка на родительский элемент'})
departmentFT = db.DsFieldTypes.insertOne({'Name':'Department', 'DisplayName':'Подразделение'})
iconTypeFT = db.DsFieldTypes.insertOne({'Name':'IconType', 'DisplayName':'Тип (иконка)'})
tableFT = db.DsFieldTypes.insertOne({'Name':'TableField', 'DisplayName':'Таблица'})
indicatorFT = db.DsFieldTypes.insertOne({'Name':'Indicator', 'DisplayName':'Индикатор'})
externalContractorFT = db.DsFieldTypes.insertOne({'Name':'ExternalContractor', 'DisplayName':'Контрагент (поиск во внешнем источнике)'})
externalBankFT = db.DsFieldTypes.insertOne({'Name':'ExternalBank', 'DisplayName':'Банк (поиск во внешнем источнике)'})
mrpaFT = db.DsFieldTypes.insertOne({'Name':'MRPA', 'DisplayName':'Машиночитаемая доверенность'})
webPartContentEditorFT = db.DsFieldTypes.insertOne({'Name':'WebPartPageEditor', 'DisplayName':'Редактор страниц'})
calculatedFT = db.DsFieldTypes.insertOne({'Name':'Calculated', 'DisplayName':'Вычисляемый'})

title = db.home.DsFields.insertOne({'Name':'Title', '_t': 'MongoTextField', 'DisplayName':'Название', 'FieldType': textFT.insertedId, 'ParentList':null, 'Required':true, 'SystemField':true})
created = db.home.DsFields.insertOne({'Name':'Created', '_t': 'MongoDateTimeField', 'DisplayName':'Создано', 'FieldType': dateFT.insertedId, 'ParentList':null, 'Required':false, 'SystemField':true})
modified = db.home.DsFields.insertOne({'Name':'Modified', '_t': 'MongoDateTimeField', 'DisplayName':'Изменено', 'FieldType': dateFT.insertedId, 'ParentList':null, 'Required':false, 'SystemField':true})
modifiedBy = db.home.DsFields.insertOne({'Name':'ModifiedBy', '_t': 'MongoUserField', 'DisplayName':'Кем изменено', 'FieldType': userFT.insertedId, 'ParentList':null, 'Required':false, 'SystemField':true, 'LookupField':'Name', 'SourceType':0, 'ValueType':[0],'TargetGroup':null})
createdBy = db.home.DsFields.insertOne({'Name':'CreatedBy', '_t': 'MongoUserField', 'DisplayName':'Кем создано', 'FieldType': userFT.insertedId, 'ParentList':null, 'Required':false, 'SystemField':true, 'LookupField':'Name', 'SourceType':0, 'ValueType':[0],'TargetGroup':null})
docState = db.home.DsFields.insertOne({'Name':'DocState', '_t': 'MongoDocumentStateField', 'DisplayName':'Состояние', 'FieldType': docStateFT.insertedId, 'ParentList':null, 'Required':false, 'SystemField':true})
dsParentLink=db.home.DsFields.insertOne({'Name':'ParentLink', '_t': 'MongoParentLinkField', 'DisplayName':'Ссылка на родительский элемент', 'FieldType': parentLinkFT.insertedId, 'ParentList':null, 'Required':false, 'SystemField':true})
iconType = db.home.DsFields.insertOne({'Name':'ItemIcon', '_t': 'MongoIconTypeField', 'DisplayName':'Тип (иконка)', 'FieldType': iconTypeFT.insertedId, 'ParentList':null, 'Required':false, 'SystemField':true})
contentType = db.home.DsFields.insertOne({'Name':'ContentType', '_t': 'MongoTextField', 'DisplayName':'Тип контента', 'FieldType': textFT.insertedId, 'ParentList':null, 'Required':false, 'SystemField':true})

regNumber = db.home.DsFields.insertOne({'Name':'RegNumber', '_t': 'MongoTextField', 'DisplayName':'Рег. номер', 'FieldType': textFT.insertedId, 'ParentList':null, 'Required':false, 'SystemField':false})
regDate = db.home.DsFields.insertOne({'Name':'RegDate', '_t': 'MongoDateTimeField', 'DisplayName':'Дата регистрации', 'FieldType': dateFT.insertedId, 'ParentList':null, 'Required':false, 'SystemField':false})
regBy = db.home.DsFields.insertOne({'Name':'RegisteredBy', '_t': 'MongoUserField', 'DisplayName':'Кем зарегистрировано', 'FieldType': userFT.insertedId, 'ParentList':null, 'Required':false, 'SystemField':false, 'LookupField':'Name', 'SourceType':0, 'ValueType':[0],'TargetGroup':null})

db.home.DsDocumentStates.insertMany([
{'Title':'Новый', 'ContentTypeId':null, 'StaticName':'NewDocument'}, 
{'Title':'Черновик', 'ContentTypeId':null, 'StaticName':'Draft'}, 
{'Title':'Отозван', 'ContentTypeId':null, 'StaticName':'Revoked'}, 
{'Title':'Зарегистрирован', 'ContentTypeId':null, 'StaticName':'Registered'}, 
{'Title':'Отменен', 'ContentTypeId':null, 'StaticName':'Canceled'},
{'Title':'Отправлен', 'ContentTypeId':null, 'StaticName':'DocSent'},
{'Title':'На подписании', 'ContentTypeId':null, 'StaticName':'DocOnSigning'},
{'Title':'На согласовании', 'ContentTypeId':null, 'StaticName':'DocOnApproval'},
{'Title':'Подписан', 'ContentTypeId':null, 'StaticName':'DocSigned'}
])
/*============ Begin DsTasks List ============*/

taskList = ({'_id':'DsTasks', 'Name':'Задачи', 'Description':'Задачи этапов маршрутов.', 'ListUrl':'DsTasks', 'ListType':100, 'EnableFolderCreation':false, 'SystemList':false, 'State':0, 'SiteId':'home', "HasUniquePermissions":false, "SecureObjectId":"home"});
db.home.DsLists.insertOne(taskList);

title_TasksField = db.home.DsFields.insertOne({'Name':'Title', '_t': 'MongoTextField', 'DisplayName':'Название', 'FieldType': textFT.insertedId, 'ParentList':'DsTasks', 'Required':true, 'SystemField':true, 'ParentFieldId':title.insertedId})
created_TasksField = db.home.DsFields.insertOne({'Name':'Created', '_t': 'MongoDateTimeField', 'DisplayName':'Создано', 'FieldType': dateFT.insertedId, 'ParentList':'DsTasks', 'Required':false, 'SystemField':true, 'ParentFieldId':created.insertedId})
modified_TasksField = db.home.DsFields.insertOne({'Name':'Modified', '_t': 'MongoDateTimeField', 'DisplayName':'Изменено', 'FieldType': dateFT.insertedId, 'ParentList':'DsTasks', 'Required':false, 'SystemField':true, 'ParentFieldId':modified.insertedId})
modifiedBy_TasksField = db.home.DsFields.insertOne({'Name':'ModifiedBy', '_t': 'MongoUserField', 'DisplayName':'Кем изменено', 'FieldType': userFT.insertedId, 'ParentList':'DsTasks', 'Required':false, 'SystemField':true, 'LookupField':'Name', 'SourceType':0, 'ValueType':[0],'TargetGroup':null, 'ParentFieldId':modifiedBy.insertedId})
createdBy_TasksField = db.home.DsFields.insertOne({'Name':'CreatedBy', '_t': 'MongoUserField', 'DisplayName':'Кем создано', 'FieldType': userFT.insertedId, 'ParentList':'DsTasks', 'Required':false, 'SystemField':true, 'LookupField':'Name', 'SourceType':0, 'ValueType':[0],'TargetGroup':null, 'ParentFieldId':createdBy.insertedId})
docState_TasksField = db.home.DsFields.insertOne({'Name':'DocState', '_t': 'MongoDocumentStateField', 'DisplayName':'Состояние', 'FieldType': docStateFT.insertedId, 'ParentList':'DsTasks', 'Required':false, 'SystemField':true, 'ParentFieldId':docState.insertedId})
dsParentLink_TasksField=db.home.DsFields.insertOne({'Name':'ParentLink', '_t': 'MongoParentLinkField', 'DisplayName':'Ссылка на родительский элемент', 'FieldType': parentLinkFT.insertedId, 'ParentList':'DsTasks', 'Required':false, 'SystemField':true, 'ParentFieldId':dsParentLink.insertedId})
iconType_TasksField = db.home.DsFields.insertOne({'Name':'ItemIcon', '_t': 'MongoIconTypeField', 'DisplayName':'Тип (иконка)', 'FieldType': iconTypeFT.insertedId, 'ParentList':'DsTasks', 'Required':false, 'SystemField':true, 'ParentFieldId':iconType.insertedId})
contentType_TasksField = db.home.DsFields.insertOne({'Name':'ContentType', '_t': 'MongoTextField', 'DisplayName':'Тип контента', 'FieldType': textFT.insertedId, 'ParentList':'DsTasks', 'Required':false, 'SystemField':true,'ParentFieldId':contentType.insertedId})

db.home.DsDocumentStates.insertMany([
{'Title':'Новая', 'ContentTypeId':null, 'StaticName':'Task_New'},
{'Title':'Не начата', 'ContentTypeId':null, 'StaticName':'Task_NotStarted'},
{'Title':'Делегирована', 'ContentTypeId':null, 'StaticName':'Task_Delegated'}
])
taskOnExecutionState = db.home.DsDocumentStates.insertOne({'Title':'На исполнении', 'ContentTypeId':null, 'StaticName':'Task_OnExecution'})
taskCanceledState = db.home.DsDocumentStates.insertOne({'Title':'Отменена', 'ContentTypeId':null, 'StaticName':'Task_Canceled'})
taskCompletedState = db.home.DsDocumentStates.insertOne({'Title':'Завершена', 'ContentTypeId':null, 'StaticName':'Task_Completed'})
taskOnConfirmationState = db.home.DsDocumentStates.insertOne({'Title':'На подтверждении', 'ContentTypeId':null, 'StaticName':'Task_OnConfirmation'})
taskReturned = db.home.DsDocumentStates.insertOne({'Title':'Возвращена', 'ContentTypeId':null, 'StaticName':'Task_ReturnedToAuthor'})

/*============ Begin Common Task Fields ============*/

taskType = db.home.DsFields.insertOne({'Name':'TaskType', '_t': 'MongoTextField', 'DisplayName':'Тип задачи', 'FieldType': textFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false});
taskOutcome = db.home.DsFields.insertOne({'Name':'TaskOutcome', '_t': 'MongoTextField', 'DisplayName':'Решение', 'FieldType': textFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false});

taskAuthor=db.home.DsFields.insertOne({'Name':'TaskAuthor', '_t': 'MongoUserField', 'DisplayName':'Автор', 'FieldType': userFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false, 'LookupField':'Name', 'Multi':false, 'SourceType':0, 'ValueType':[0],'TargetGroup':null});
assignedTo=db.home.DsFields.insertOne({'Name':'AssignedTo', '_t': 'MongoUserField', 'DisplayName':'Кому назначена', 'FieldType': userFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false, 'LookupField':'Name', 'Multi':true, 'SourceType':0, 'ValueType':[0,1,2],'TargetGroup':null});
assignedToGroup=db.home.DsFields.insertOne({'Name':'AssignedToGroup', '_t': 'MongoUserField', 'DisplayName':'Группа назначения', 'FieldType': userFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false, 'LookupField':'Name', 'Multi':false, 'SourceType':0, 'ValueType':[1,2],'TargetGroup':null});
executedBy=db.home.DsFields.insertOne({'Name':'ExecutedBy', '_t': 'MongoUserField', 'DisplayName':'Кто исполнил', 'FieldType': userFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false, 'LookupField':'Name', 'Multi':false, 'SourceType':0, 'ValueType':[0],'TargetGroup':null});
stageDelegate=db.home.DsFields.insertOne({'Name':'StageDelegate', '_t': 'MongoUserField', 'DisplayName':'Кому делегирована', 'FieldType': userFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false, 'LookupField':'Name', 'Multi':false, 'SourceType':0, 'ValueType':[0],'TargetGroup':null});

stageComment=db.home.DsFields.insertOne({'Name':'StageComment', '_t': 'MongoNoteField', 'DisplayName':'Комментарий', 'FieldType': noteFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false, 'DisplayFormat':0, 'RowCount':3});
taskDelegationComment=db.home.DsFields.insertOne({'Name':'TaskDelegationComment', '_t': 'MongoNoteField', 'DisplayName':'Комментарий к делегированию задачи', 'FieldType': noteFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false, 'DisplayFormat':0, 'RowCount':10});
instruction=db.home.DsFields.insertOne({'Name':'Instruction', '_t': 'MongoNoteField', 'DisplayName':'Описание', 'FieldType': noteFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false, 'DisplayFormat':0, 'RowCount':5});

taskStartDate=db.home.DsFields.insertOne({'Name':'TaskStartDate', '_t': 'MongoDateTimeField', 'DisplayName':'Дата постановки', 'FieldType': dateFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false, 'DateOnly':false});
taskDueDate=db.home.DsFields.insertOne({'Name':'TaskDueDate', '_t': 'MongoDateTimeField', 'DisplayName':'Срок исполнения', 'FieldType': dateFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false, 'DateOnly':false, 'DefaultValueFormula':'Time:23-59'});
taskFinishDate=db.home.DsFields.insertOne({'Name':'TaskFinishDate', '_t': 'MongoDateTimeField', 'DisplayName':'Дата исполнения', 'FieldType': dateFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false, 'DateOnly':false});
acquaintanceDate=db.home.DsFields.insertOne({'Name':'TaskAcknowledgeDate', '_t': 'MongoDateTimeField', 'DisplayName':'Дата ознакомления', 'FieldType': dateFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false, 'DateOnly':false});

completed=db.home.DsFields.insertOne({'Name':'Completed', '_t': 'MongoBooleanField', 'DisplayName':'Завершена', 'FieldType': boolFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false});

taskReason=db.home.DsFields.insertOne({'Name':'TaskReason', '_t': 'MongoParentLinkField', 'DisplayName':'Основание', 'FieldType': parentLinkFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false})

taskStateIndicator=db.home.DsFields.insertOne(
{'Name':'TaskStateIndicator', 
'_t': 'MongoIndicatorField', 
'DisplayName':'Индикатор состояния документа', 'FieldType': indicatorFT.insertedId, 'ParentList':taskList._id, 
'Required':false, 'SystemField':false, 'IndicatorField':'DocState', 
'Rules':[
{'FieldValue':taskOnExecutionState.insertedId.toString(), 'ImageName':'StateIconInProgress'},
{'FieldValue':taskCanceledState.insertedId.toString(), 'ImageName':'StateIconCanceled'},
{'FieldValue':taskCompletedState.insertedId.toString(), 'ImageName':'StateIconCompleted'},
{'FieldValue':taskOnConfirmationState.insertedId.toString(), 'ImageName':'StateIconOnConfirmation'},
{'FieldValue':taskReturned.insertedId.toString(), 'ImageName':'DocumentReturnedTaskIcon'}
]
});
taskTypeIndicator=db.home.DsFields.insertOne(
{'Name':'TaskTypeIndicator', 
'_t': 'MongoIndicatorField', 
'DisplayName':'Индикатор типа задачи', 'FieldType': indicatorFT.insertedId, 'ParentList':taskList._id, 
'Required':false, 'SystemField':false, 'IndicatorField':'TaskType', 
'Rules':[
{'FieldValue':'Задача рабочего процесса', 'ImageName':'RouteTaskIcon'},
{'FieldValue':'Исполнение', 'ImageName':'DocumentTaskIcon'},
{'FieldValue':'Задача', 'ImageName':'DocumentTaskIcon'},
{'FieldValue':'Согласование', 'ImageName':'DocumentTaskIcon'},
{'FieldValue':'Подписание', 'ImageName':'DocumentTaskIcon'},
{'FieldValue':'Ознакомление', 'ImageName':'DocumentTaskIcon'}
]
});

/*============ End Common Task Fields ============*/

tasksView = db.home.DsViews.insertOne({'Name':'Все задачи', 'ParentList':taskList._id, 'Filter':null, 'Sort':null, 'ShowFolder':false, 'PageSize':50,
'Fields':[
  {'FieldId': title_TasksField.insertedId, 'Position': 1},
  {'FieldId': created_TasksField.insertedId, 'Position': 2},
  {'FieldId': createdBy_TasksField.insertedId, 'Position': 3},
  {'FieldId': assignedTo.insertedId, 'Position': 4},
  {'FieldId': taskDueDate.insertedId, 'Position': 5},
  {'FieldId': completed.insertedId, 'Position': 6},
  {'FieldId': taskOutcome.insertedId, 'Position': 7}
]});


myTasksView = db.home.DsViews.insertOne({'Name':'Мои', 'StaticName':'DsMyTasks', 'ParentList':taskList._id, 
'Filter':'{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"AssignedTo","Value":"Me","TypeAsString":"UserMulti"}}],"FieldCondition":null}', 
'Sort':'{"FieldInternalName":"Created","Order":-1}', 
'PageSize':50,
'ShowFolder':false, 
'Fields':[
  {'FieldId': title_TasksField.insertedId, 'Position': 1},
  {'FieldId': created_TasksField.insertedId, 'Position': 2},
  {'FieldId': createdBy_TasksField.insertedId, 'Position': 3},
  {'FieldId': assignedTo.insertedId, 'Position': 4},
  {'FieldId': taskDueDate.insertedId, 'Position': 5},
  {'FieldId': completed.insertedId, 'Position': 6},
  {'FieldId': taskOutcome.insertedId, 'Position': 7}
]});

completedTasksView = db.home.DsViews.insertOne({'Name':'Завершены', 'StaticName':'DsCompletedTasks', 'ParentList':taskList._id, 
'Filter':'{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":0,"Field":"Completed","Value":"да","TypeAsString":"Boolean"}}],"FieldCondition":null}', 
'Sort':'{"FieldInternalName":"Created","Order":-1}', 
'PageSize':50, 
'ShowFolder':false, 
'Fields':[
  {'FieldId': title_TasksField.insertedId, 'Position': 1},
  {'FieldId': created_TasksField.insertedId, 'Position': 2},
  {'FieldId': createdBy_TasksField.insertedId, 'Position': 3},
  {'FieldId': assignedTo.insertedId, 'Position': 4},
  {'FieldId': taskDueDate.insertedId, 'Position': 5},
  {'FieldId': completed.insertedId, 'Position': 6},
  {'FieldId': taskOutcome.insertedId, 'Position': 7}
]});

inProgressView = db.home.DsViews.insertOne({'Name':'На исполнении', 'StaticName':'DsTasksOnExecution', 'ParentList':taskList._id, 
'Filter':'{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":1,"Field":"Completed","Value":"нет","TypeAsString":"Boolean"}}],"FieldCondition":null}', 
'Sort':'{"FieldInternalName":"Created","Order":-1}', 
'PageSize':50, 
'ShowFolder':false, 
'Fields':[
  {'FieldId': title_TasksField.insertedId, 'Position': 1},
  {'FieldId': created_TasksField.insertedId, 'Position': 2},
  {'FieldId': createdBy_TasksField.insertedId, 'Position': 3},
  {'FieldId': assignedTo.insertedId, 'Position': 4},
  {'FieldId': taskDueDate.insertedId, 'Position': 5},
  {'FieldId': completed.insertedId, 'Position': 6},
  {'FieldId': taskOutcome.insertedId, 'Position': 7}
]});


db.home.DsLists.updateOne(
{'ListUrl':'DsTasks'},
{$set: { "DefaultView" : tasksView.insertedId}});

db.home.DsNavigationMenu.insertOne({'Title':'Задачи', 'UniqueId':'{AF7B4F62-3E9D-46B6-BF08-483DB5DB64D6}', 'Link':'DsTasks', 'View':tasksView.insertedId, 'Position':1, 'ParentNodeUniqueId':'', 'HideCreateItemButton':false, 'TitleLinkMode':'view', 'ShowItemsCount':false, 'ShowInNewTab':false, 'AllowedPrincipals':[],'NodeType':0,'TitleDisplayMode':0,'ShowExportViewButton':false });


/*============ End DsTasks List ============*/


/*============ Begin Workflow Task ============*/

stageName = db.home.DsFields.insertOne({'Name':'StageName', '_t': 'MongoTextField', 'DisplayName':'Этап', 'FieldType': textFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false, 'Hidden':true});
routeInstanceId = db.home.DsFields.insertOne({'Name':'RouteInstanceId', '_t': 'MongoTextField', 'DisplayName':'RouteInstanceId', 'FieldType': textFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false, 'Hidden':true});
currentFlowId = db.home.DsFields.insertOne({'Name':'CurrentFlowId', '_t': 'MongoTextField', 'DisplayName':'CurrentFlowId', 'FieldType': textFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false, 'Hidden':true});
routeListId = db.home.DsFields.insertOne({'Name':'RouteListId', '_t': 'MongoTextField', 'DisplayName':'RouteListId', 'FieldType': textFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false, 'Hidden':true});
routeItemId = db.home.DsFields.insertOne({'Name':'RouteItemId', '_t': 'MongoTextField', 'DisplayName':'RouteItemId', 'FieldType': textFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false, 'Hidden':true});

workflowTaskCt = db.home.DsContentTypes.insertOne(
{
'Name':'Задача рабочего процесса',
'StaticName':'WorkflowTask',
'FileSysObjectType':2,
'ParentListId':taskList._id, 
'FormActionJson':null,
'FormStateJson':'[{"Role":null,"Name":"\u041F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E","TaskExecutor":false,"DocState":[],"Filter":null,"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAcknowledgeDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[{"Id":"Conteq.iSpace.Tasks.Actions.CreateTaskAction","Visible":true,"Enabled":true},{"Id":"Conteq.iSpace.Tasks.Actions.CreateSubTaskAction","Visible":true,"Enabled":true}],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u002B \u041A\u043E\u043C\u0443","TaskExecutor":false,"DocState":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"AssignedTo","Value":"Me","TypeAsString":"UserMulti"}},{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddaf","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"StageDelegate","Hidden":false,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430/\u041E\u0442\u043C\u0435\u043D\u0435\u043D\u0430","TaskExecutor":false,"DocState":[],"Filter":{"ClosureOperator":2,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddb4","TypeAsString":"DocumentState"}},{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddb2","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskOutcome","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageDelegate","Hidden":false,"Required":false,"ReadOnly":true}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u0414\u0435\u043B\u0435\u0433\u0438\u0440\u043E\u0432\u0430\u043D\u0430","TaskExecutor":false,"DocState":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddb3","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskOutcome","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageDelegate","Hidden":false,"Required":false,"ReadOnly":true}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u002B \u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E","TaskExecutor":false,"DocState":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddaf","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAuthor","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[{"Id":"Conteq.iSpace.Tasks.Actions.CreateSubTaskAction","Visible":true,"Enabled":true}],"Priority":1},{"Role":"64257a713111d8ce589d6e49","Name":"\u041D\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u002B \u0430\u0434\u043C\u0438\u043D","TaskExecutor":false,"DocState":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddaf","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAuthor","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[{"Id":"Conteq.iSpace.Tasks.Actions.CreateTaskAction","Visible":true,"Enabled":true},{"Id":"Conteq.iSpace.Tasks.Actions.CreateSubTaskAction","Visible":true,"Enabled":true}],"Priority":1}]',
'FormJson':'{\"fields\":[\"dsParentLink\",\"RouteInstanceId\",\"RouteItemId\",\"RouteListId\",\"TaskAuthor\",\"AssignedToGroup\",\"TaskFinishDate\",\"TaskStartDate\",\"StageDelegate\",\"Completed\",\"Modified\",\"ModifiedBy\",\"CreatedBy\",\"StageComment\",\"AssignedTo\",\"ExecutedBy\",\"Title\",\"Instruction\",\"TaskOutcome\",\"Created\",\"TaskStatus\",\"TaskDueDate\",\"ParentLink\",\"ItemIcon\",\"StageName\"],\"formType\":\"page\",\"tabs\":[{\"key\":\"ItemProps\",\"title\":\"Задача\",\"type\":\"itemProps\",\"metadata\":{\"sections\":[{\"id\":0,\"title\":\"\",\"collapsed\":false,\"displayAll\":false,\"showTooltip\":false,\"textTooltip\":\"\",\"rows\":[{\"colls\":[{\"name\":\"AssignedTo\",\"required\":false,\"readOnly\":false,\"hidden\":false,\"widthRules\":\"ms-md6\"},{\"name\":\"TaskDueDate\",\"required\":false,\"readOnly\":false,\"hidden\":false,\"widthRules\":\"ms-md6\"}]},{\"colls\":[{\"name\":\"Title\",\"required\":false,\"readOnly\":false,\"hidden\":false,\"widthRules\":\"ms-md12\"}]},{\"colls\":[{\"name\":\"Instruction\",\"required\":false,\"readOnly\":false,\"hidden\":false,\"widthRules\":\"ms-md12\"}]},{\"colls\":[{\"name\":\"StageComment\",\"required\":false,\"readOnly\":false,\"hidden\":false,\"widthRules\":\"ms-md12\"}]},{\"colls\":[{\"name\":\"ParentLink\",\"required\":false,\"readOnly\":false,\"hidden\":false,\"widthRules\":\"ms-md12\"}]},{\"colls\":[{\"name\":\"TaskAuthor\",\"required\":false,\"readOnly\":false,\"hidden\":false,\"widthRules\":\"ms-md6\"},{\"name\":\"TaskStartDate\",\"required\":false,\"readOnly\":false,\"hidden\":false,\"widthRules\":\"ms-md6\"}]},{\"colls\":[{\"name\":\"TaskAcknowledgeDate\",\"required\":false,\"readOnly\":false,\"hidden\":false,\"widthRules\":\"ms-md6\"}]},{\"colls\":[{\"name\":\"ExecutedBy\",\"required\":false,\"readOnly\":false,\"hidden\":false,\"widthRules\":\"ms-md6\"},{\"name\":\"TaskFinishDate\",\"required\":false,\"readOnly\":false,\"hidden\":false,\"widthRules\":\"ms-md6\"}]},{\"colls\":[{\"name\":\"TaskOutcome\",\"required\":false,\"readOnly\":false,\"hidden\":false,\"widthRules\":\"ms-md6\"}]}]},{\"id\":1,\"title\":\"\",\"collapsed\":true,\"displayAll\":false,\"showTooltip\":false,\"textTooltip\":\"\",\"rows\":[]}]}}],\"showParentDoc\":true}',
'FieldRefs':[title_TasksField.insertedId,  created_TasksField.insertedId, createdBy_TasksField.insertedId,modified_TasksField.insertedId, modifiedBy_TasksField.insertedId, docState_TasksField.insertedId, dsParentLink_TasksField.insertedId,
contentType_TasksField.insertedId,
taskAuthor.insertedId,
taskType.insertedId,
taskStartDate.insertedId,
taskReason.insertedId,
assignedTo.insertedId,
assignedToGroup.insertedId,
executedBy.insertedId,
stageDelegate.insertedId,
instruction.insertedId,
stageComment.insertedId,
taskDelegationComment.insertedId,
taskDueDate.insertedId,
taskFinishDate.insertedId,
acquaintanceDate.insertedId,
taskOutcome.insertedId,
completed.insertedId,
stageName.insertedId,
routeInstanceId.insertedId,
currentFlowId.insertedId,
routeListId.insertedId,
routeItemId.insertedId
]});
/*============ End Workflow Task ============*/


/*============ Begin Template Tasks ============*/

priority=db.home.DsFields.insertOne({'Name':'TaskPriority', '_t': 'MongoBooleanField', 'DisplayName':'Важность', 'FieldType': boolFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false})
confirmRequired=db.home.DsFields.insertOne({'Name':'RequiredConfirmation', '_t': 'MongoBooleanField', 'DisplayName':'Требуется подтверждение', 'FieldType': boolFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false})
taskCoexecutors=db.home.DsFields.insertOne({'Name':'TaskCoexecutors', '_t': 'MongoUserField', 'DisplayName':'Соисполнители', 'FieldType': userFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false, 'LookupField':'Name', 'Multi':true, 'SourceType':0, 'ValueType':[0],'TargetGroup':null});
observers=db.home.DsFields.insertOne({'Name':'Observers', '_t': 'MongoUserField', 'DisplayName':'Наблюдатели', 'FieldType': userFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false, 'LookupField':'Name', 'Multi':true, 'SourceType':0, 'ValueType':[0],'TargetGroup':null});
taskController=db.home.DsFields.insertOne({'Name':'TaskController', '_t': 'MongoUserField', 'DisplayName':'Контролер', 'FieldType': userFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false, 'LookupField':'Name', 'Multi':false, 'SourceType':0, 'ValueType':[0],'TargetGroup':null});
taskConfirmDate=db.home.DsFields.insertOne({'Name':'ConfirmationDate', '_t': 'MongoDateTimeField', 'DisplayName':'Дата подтверждения', 'FieldType': dateFT.insertedId, 'ParentList':taskList._id, 'Required':false, 'SystemField':false, 'DateOnly':false});

docTask = db.home.DsContentTypes.insertOne(
{
'Name':'Задача',
'StaticName':'DocumentTask',
'FileSysObjectType':2,
'ParentListId':taskList._id, 
'FormStateJson':'[{"Role":null,"Name":"\u041F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":null,"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":true,"ReadOnly":false},{"Name":"TaskDueDate","Hidden":false,"Required":true,"ReadOnly":false},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":false},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"StageComment","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskStartDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAcknowledgeDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[{"Id":"Conteq.iSpace.WebApi.Actions.RevokeDocumentAction","Visible":false,"Enabled":false},{"Id":"Conteq.iSpace.Tasks.Actions.CreateTaskAction","Visible":true,"Enabled":true},{"Id":"Conteq.iSpace.WebApi.Actions.AddAttachmentAction","Visible":true,"Enabled":true},{"Id":"Conteq.iSpace.WebApi.Actions.PrintFormAction","Visible":false,"Enabled":false},{"Id":"Conteq.iSpace.Registration.Actions.RegisterItemAction","Visible":false,"Enabled":false},{"Id":"Conteq.iSpace.Tasks.Actions.CreateSubTaskAction","Visible":true,"Enabled":true},{"Id":"Conteq.iSpace.Routes.Actions.RevokeAction","Visible":false,"Enabled":true}],"Priority":1},{"Role":"64257a713111d8ce589d6e49","Name":"\u041D\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u002B \u0430\u0434\u043C\u0438\u043D","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddaf","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":false},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Observers","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskCoexecutors","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"RequiredConfirmation","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[{"Id":"Conteq.iSpace.WebApi.Actions.RevokeDocumentAction","Visible":true,"Enabled":true}],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u002B \u0430\u0432\u0442\u043E\u0440","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddaf","TypeAsString":"DocumentState"}},{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"CreatedBy","Value":"Me","TypeAsString":"User"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"RequiredConfirmation","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[{"Id":"Conteq.iSpace.WebApi.Actions.RevokeDocumentAction","Visible":true,"Enabled":true}],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u002B \u043A\u043E\u043C\u0443","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"AssignedTo","Value":"Me","TypeAsString":"UserMulti"}},{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddaf","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Observers","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskCoexecutors","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"RequiredConfirmation","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[{"Id":"Conteq.iSpace.WebApi.Actions.RevokeDocumentAction","Visible":true,"Enabled":true}],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0438 \u002B \u0430\u0432\u0442\u043E\u0440","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"TaskAuthor","Value":"Me","TypeAsString":"User"}},{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddb0","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Observers","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskCoexecutors","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"RequiredConfirmation","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":false,"Required":false,"ReadOnly":true}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0438 \u002B \u043A\u043E\u043D\u0442\u0440\u043E\u043B\u0435\u0440","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddb0","TypeAsString":"DocumentState"}},{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"TaskController","Value":"Me","TypeAsString":"UserMulti"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Observers","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskCoexecutors","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"RequiredConfirmation","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":false,"Required":false,"ReadOnly":true}],"ActionSettings":[],"Priority":1},{"Role":"64257a713111d8ce589d6e49","Name":"\u041D\u0430 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0438 \u002B \u0430\u0434\u043C\u0438\u043D","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddb0","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":false},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":false,"Required":false,"ReadOnly":true}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u002B \u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddaf","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Observers","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskCoexecutors","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"RequiredConfirmation","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0438 \u002B \u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddb0","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Observers","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskCoexecutors","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"RequiredConfirmation","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":false,"Required":false,"ReadOnly":true}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430/\u041E\u0442\u043C\u0435\u043D\u0435\u043D\u0430","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":2,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddb4","TypeAsString":"DocumentState"}},{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddb2","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Observers","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskCoexecutors","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"RequiredConfirmation","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ConfirmationDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskOutcome","Hidden":false,"Required":false,"ReadOnly":true}],"ActionSettings":[],"Priority":1}]',
'FormJson':'{"fields":["TaskAuthor","TaskPriority","AssignedToGroup","TaskFinishDate","TaskAcknowledgeDate","ConfirmationDate","TaskStartDate","StageDelegate","Completed","Modified","ModifiedBy","CreatedBy","TaskOutcomeComment","AssignedTo","TaskController","ExecutedBy","Observers","Title","Instruction","TaskReason","TaskOutcome","Created","TaskCoexecutors","DocState","TaskDueDate","ParentLink","TaskSubject","ItemIcon","TaskType","RequiredConfirmation"],"formType":"page","tabs":[{"key":"ItemProps","title":"Задача","type":"itemProps","metadata":{"sections":[{"id":0,"title":"","collapsed":false,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[{"colls":[{"name":"AssignedTo","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md7"},{"name":"TaskDueDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md5"}]},{"colls":[{"name":"Title","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]},{"colls":[{"name":"Instruction","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]},{"colls":[{"name":"StageComment","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]},{"colls":[{"name":"TaskReason","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12","additionalSettings":{"displayValueFilled":true}}]},{"colls":[{"name":"ParentLink","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12","additionalSettings":{"displayValueFilled":true}}]}]},{"id":1,"title":"Дополнительные параметры","collapsed":true,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[{"colls":[{"name":"TaskController","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"Observers","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"TaskCoexecutors","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"RequiredConfirmation","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md3"}]}]},{"id":2,"title":"Исполнение","collapsed":true,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[{"colls":[{"name":"TaskAuthor","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"TaskStartDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"TaskAcknowledgeDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"ExecutedBy","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"TaskFinishDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"ConfirmationDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"TaskOutcome","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]}]},{"id":3,"title":"Вложения","type":"attachments","attachments":{},"collapsed":true,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[]},{"id":4,"title":"","collapsed":true,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[]}]}}]}',
'FieldRefs':[title_TasksField.insertedId, created_TasksField.insertedId, createdBy_TasksField.insertedId,modified_TasksField.insertedId, modifiedBy_TasksField.insertedId,docState_TasksField.insertedId,
iconType_TasksField.insertedId,
dsParentLink_TasksField.insertedId,
contentType_TasksField.insertedId,
instruction.insertedId,
assignedTo.insertedId,
assignedToGroup.insertedId,
taskDueDate.insertedId,
taskReason.insertedId,
taskType.insertedId,
taskAuthor.insertedId,
taskStartDate.insertedId,
taskOutcome.insertedId,
stageDelegate.insertedId,
completed.insertedId,
stageComment.insertedId,
taskDelegationComment.insertedId,
priority.insertedId,
taskCoexecutors.insertedId,
taskController.insertedId,
confirmRequired.insertedId,
observers.insertedId,
acquaintanceDate.insertedId,
executedBy.insertedId,
taskFinishDate.insertedId,
taskConfirmDate.insertedId 
],
'DefaultFieldValues':{
'TaskType':'Задача'
},
'Properties':
{
'DefaultTaskDecisions' : {'ReturnTaskToAuthorActionAvailable':true, 'DelegateTaskActionAvailable':true}, 
'is_ItemInitializator' : 'Conteq.iSpace.Tasks.Services.Initialization.TasksBaseInitializer'
}
});


agreementTask = db.home.DsContentTypes.insertOne(
{
'Name':'Согласование',
'StaticName':'AgreementTask',
'FileSysObjectType':2,
'ParentListId':taskList._id, 
'FormStateJson':'[{"Role":null,"Name":"\u041F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":null,"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":true,"ReadOnly":false},{"Name":"TaskDueDate","Hidden":false,"Required":true,"ReadOnly":false},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":true,"ReadOnly":false},{"Name":"StageComment","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskStartDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAcknowledgeDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[{"Id":"Conteq.iSpace.WebApi.Actions.AddAttachmentAction","Visible":true,"Enabled":true},{"Id":"Conteq.iSpace.WebApi.Actions.RevokeDocumentAction","Visible":true,"Enabled":true},{"Id":"Conteq.iSpace.Tasks.Actions.CreateTaskAction","Visible":true,"Enabled":true},{"Id":"Conteq.iSpace.Routes.Actions.RevokeAction","Visible":false,"Enabled":true}],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u002B \u0410\u0432\u0442\u043E\u0440","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"CreatedBy","Value":"Me","TypeAsString":"User"}},{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddaf","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u002B \u041A\u043E\u043C\u0443","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddaf","TypeAsString":"DocumentState"}},{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"AssignedTo","Value":"Me","TypeAsString":"UserMulti"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u002B \u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddaf","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1},{"Role":"64257a713111d8ce589d6e49","Name":"\u041D\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u002B \u0410\u0434\u043C\u0438\u043D","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddaf","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":false},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430/\u041E\u0442\u043C\u0435\u043D\u0435\u043D\u0430","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":2,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddb2","TypeAsString":"DocumentState"}},{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddb4","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskOutcome","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1}]',
'FormJson':'{"fields":["TaskAuthor","TaskPriority","AssignedToGroup","TaskFinishDate","TaskAcknowledgeDate","ConfirmationDate","TaskStartDate","StageDelegate","Completed","Modified","ModifiedBy","CreatedBy","TaskOutcomeComment","AssignedTo","TaskController","ExecutedBy","Observers","Title","Instruction","TaskReason","TaskOutcome","Created","TaskCoexecutors","DocState","TaskDueDate","ParentLink","TaskSubject","ItemIcon","TaskType","RequiredConfirmation"],"formType":"page","tabs":[{"key":"ItemProps","title":"Задача","type":"itemProps","metadata":{"sections":[{"id":0,"title":"","collapsed":false,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[{"colls":[{"name":"AssignedTo","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"TaskDueDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"Title","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]},{"colls":[{"name":"Instruction","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]},{"colls":[{"name":"StageComment","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]},{"colls":[{"name":"ParentLink","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12","additionalSettings":{"displayValueFilled":true}}]},{"colls":[{"name":"TaskReason","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12","additionalSettings":{"displayValueFilled":true}}]}]},{"id":1,"title":"Дополнительные параметры","collapsed":true,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[{"colls":[{"name":"TaskController","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"Observers","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"TaskCoexecutors","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"RequiredConfirmation","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md4"}]}]},{"id":2,"title":"Исполнение","collapsed":true,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[{"colls":[{"name":"TaskAuthor","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"TaskStartDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"TaskAcknowledgeDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"ExecutedBy","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"TaskFinishDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"TaskOutcome","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"ConfirmationDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]}]},{"id":3,"title":"Вложения","type":"attachments","attachments":{},"collapsed":true,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[]}]}}]}',
'FieldRefs':[title_TasksField.insertedId, created_TasksField.insertedId, createdBy_TasksField.insertedId,modified_TasksField.insertedId, modifiedBy_TasksField.insertedId,docState_TasksField.insertedId,
contentType_TasksField.insertedId,
iconType_TasksField.insertedId,
dsParentLink_TasksField.insertedId,
instruction.insertedId,
assignedTo.insertedId,
assignedToGroup.insertedId,
taskDueDate.insertedId,
completed.insertedId,
taskReason.insertedId,
taskType.insertedId,
taskOutcome.insertedId,
stageComment.insertedId,
taskDelegationComment.insertedId,
taskAuthor.insertedId,
taskStartDate.insertedId,
priority.insertedId,
taskCoexecutors.insertedId,
taskController.insertedId,
confirmRequired.insertedId,
observers.insertedId,
acquaintanceDate.insertedId,
executedBy.insertedId,
stageDelegate.insertedId,
taskFinishDate.insertedId,
taskConfirmDate.insertedId 
],
'Properties':
{ 
'DefaultTaskDecisions' : {'ReturnTaskToAuthorActionAvailable':true, 'DelegateTaskActionAvailable':true},
'TaskDecisions' : [{'Command':'{291F0750-0838-4A64-81E2-48CB15FFC518}', 'Title':'Согласовать', 'TaskOutcome':'Согласовано', 'State':'Task_Completed', 'RequiredComment':false, 'RedirectPage':1}, {'Command':'{98428A76-D12E-4439-90D9-764F44602CF8}', 'Title':'Отклонить', 'TaskOutcome':'Отклонено', 'State':'Task_Completed', 'RequiredComment':false, 'RedirectPage':1}] ,
'is_ItemInitializator' : 'Conteq.iSpace.Tasks.Services.Initialization.TasksBaseInitializer'
},
'DefaultFieldValues':{
'Title':'Согласование',
'TaskType':'Согласование'
}
});

signingTask = db.home.DsContentTypes.insertOne(
{
'Name':'Подписание',
'StaticName':'SigningTask',
'FileSysObjectType':2,
'ParentListId':taskList._id, 
'FormStateJson':'[{"Role":null,"Name":"\u041F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":null,"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":true,"ReadOnly":false},{"Name":"TaskDueDate","Hidden":false,"Required":true,"ReadOnly":false},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"StageComment","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskStartDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAcknowledgeDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[{"Id":"Conteq.iSpace.Routes.Actions.RevokeAction","Visible":false,"Enabled":true}],"Priority":1},{"Role":"64257a713111d8ce589d6e49","Name":"\u041D\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u002B \u0430\u0434\u043C\u0438\u043D","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddaf","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":true,"ReadOnly":false},{"Name":"TaskDueDate","Hidden":false,"Required":true,"ReadOnly":false},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u002B \u0430\u0432\u0442\u043E\u0440","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddaf","TypeAsString":"DocumentState"}},{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"TaskAuthor","Value":"Me","TypeAsString":"User"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u002B \u043A\u043E\u043C\u0443","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddaf","TypeAsString":"DocumentState"}},{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"AssignedTo","Value":"Me","TypeAsString":"UserMulti"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u002B \u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddaf","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430/\u041E\u0442\u043C\u0435\u043D\u0435\u043D\u0430","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddb4","TypeAsString":"DocumentState"}},{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddb4","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskOutcome","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1}]',
'FormJson':'{"fields":["TaskAuthor","TaskPriority","AssignedToGroup","TaskFinishDate","TaskAcknowledgeDate","ConfirmationDate","TaskStartDate","StageDelegate","Completed","Modified","ModifiedBy","CreatedBy","TaskOutcomeComment","AssignedTo","TaskController","ExecutedBy","Observers","Title","Instruction","TaskReason","TaskOutcome","Created","TaskCoexecutors","DocState","TaskDueDate","ParentLink","TaskSubject","ItemIcon","TaskType","RequiredConfirmation"],"formType":"page","tabs":[{"key":"ItemProps","title":"Задача","type":"itemProps","metadata":{"sections":[{"id":0,"title":"","collapsed":false,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[{"colls":[{"name":"AssignedTo","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"TaskDueDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"Title","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]},{"colls":[{"name":"Instruction","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]},{"colls":[{"name":"StageComment","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]},{"colls":[{"name":"ParentLink","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]},{"colls":[{"name":"TaskReason","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]}]},{"id":1,"title":"Дополнительные параметры","collapsed":true,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[{"colls":[{"name":"TaskController","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"Observers","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"TaskCoexecutors","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"RequiredConfirmation","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md4"}]}]},{"id":2,"title":"Исполнение","collapsed":true,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[{"colls":[{"name":"TaskAuthor","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"TaskStartDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"ExecutedBy","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"TaskAcknowledgeDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"TaskFinishDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"TaskOutcome","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"ConfirmationDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]}]},{"id":3,"title":"Вложения","type":"attachments","attachments":{},"collapsed":true,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[]}]}}]}',
'FieldRefs':[title_TasksField.insertedId, created_TasksField.insertedId, createdBy_TasksField.insertedId,modified_TasksField.insertedId, modifiedBy_TasksField.insertedId,docState_TasksField.insertedId,
iconType_TasksField.insertedId,
contentType_TasksField.insertedId,
dsParentLink_TasksField.insertedId,
instruction.insertedId,
assignedTo.insertedId,
assignedToGroup.insertedId,
completed.insertedId,
taskDueDate.insertedId,
stageDelegate.insertedId,
taskReason.insertedId,
taskType.insertedId,
taskOutcome.insertedId,
stageComment.insertedId,
taskDelegationComment.insertedId,
taskAuthor.insertedId,
taskStartDate.insertedId,
priority.insertedId,
taskCoexecutors.insertedId,
taskController.insertedId,
confirmRequired.insertedId,
observers.insertedId,
acquaintanceDate.insertedId,
executedBy.insertedId,
taskFinishDate.insertedId,
taskConfirmDate.insertedId 
],
'Properties':
{ 
'is_ItemInitializator' : 'Conteq.iSpace.Tasks.Services.Initialization.TasksBaseInitializer',
'DefaultTaskDecisions' : {'ReturnTaskToAuthorActionAvailable':true, 'DelegateTaskActionAvailable':true},
'TaskDecisions' : [{'Command':'{4566077B-DB0C-4E7D-900B-961E5871511F}', 'Title':'Подписать', 'TaskOutcome':'Подписано', 'State':'Task_Completed', 'RequiredComment':false, 'RedirectPage':1}, {'Command':'{CAE215D4-4637-406A-BE70-05DE829010FB}', 'Title':'Отклонить', 'TaskOutcome':'Отклонено', 'State':'Task_Completed', 'RequiredComment':false, 'RedirectPage':1}] 
},
'DefaultFieldValues':{
'Title':'Подписание',
'TaskType':'Подписание'
}
});

confirmationTask = db.home.DsContentTypes.insertOne(
{
'Name':'Ознакомление',
'StaticName':'ConfirmationTask',
'FileSysObjectType':2,
'ParentListId':taskList._id, 
'FormStateJson':'[{"Role":null,"Name":"\u041F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E","TaskExecutor":false,"DocState":[],"Filter":null,"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"StageComment","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskStartDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAcknowledgeDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[{"Id":"Conteq.iSpace.WebApi.Actions.AddAttachmentAction","Visible":true,"Enabled":true},{"Id":"Conteq.iSpace.WebApi.Actions.RevokeDocumentAction","Visible":true,"Enabled":true},{"Id":"Conteq.iSpace.Tasks.Actions.CreateTaskAction","Visible":true,"Enabled":true},{"Id":"Conteq.iSpace.Routes.Actions.RevokeAction","Visible":false,"Enabled":true}],"Priority":1},{"Role":"64257a713111d8ce589d6e49","Name":"\u041D\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u002B \u0430\u0434\u043C\u0438\u043D","TaskExecutor":false,"DocState":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddaf","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u002B \u0430\u0432\u0442\u043E\u0440","TaskExecutor":false,"DocState":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddaf","TypeAsString":"DocumentState"}},{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"CreatedBy","Value":"Me","TypeAsString":"User"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u002B \u043A\u043E\u043C\u0443","TaskExecutor":false,"DocState":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddaf","TypeAsString":"DocumentState"}},{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"AssignedTo","Value":"Me","TypeAsString":"UserMulti"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u002B \u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E","TaskExecutor":false,"DocState":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddaf","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430/\u041E\u0442\u043C\u0435\u043D\u0435\u043D\u0430","TaskExecutor":false,"DocState":[],"Filter":{"ClosureOperator":2,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddb2","TypeAsString":"DocumentState"}},{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddb4","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ParentLink","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskOutcome","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1}]',
'FormJson':'{"fields":["TaskAuthor","TaskPriority","AssignedToGroup","TaskFinishDate","TaskAcknowledgeDate","ConfirmationDate","TaskStartDate","StageDelegate","Completed","Modified","ModifiedBy","CreatedBy","TaskOutcomeComment","AssignedTo","TaskController","ExecutedBy","Observers","Title","Instruction","TaskReason","TaskOutcome","Created","TaskCoexecutors","DocState","TaskDueDate","ParentLink","TaskSubject","ItemIcon","TaskType","RequiredConfirmation"],"formType":"page","tabs":[{"key":"ItemProps","title":"Задача","type":"itemProps","metadata":{"sections":[{"id":0,"title":"","collapsed":false,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[{"colls":[{"name":"AssignedTo","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"TaskDueDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"Title","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]},{"colls":[{"name":"Instruction","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]},{"colls":[{"name":"StageComment","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]},{"colls":[{"name":"ParentLink","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]}]},{"id":1,"title":"Дополнительные параметры","collapsed":true,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[{"colls":[{"name":"TaskController","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"Observers","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"TaskCoexecutors","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"RequiredConfirmation","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]}]},{"id":2,"title":"Исполнение","collapsed":true,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[{"colls":[{"name":"TaskAuthor","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"TaskStartDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"ExecutedBy","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"TaskAcknowledgeDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"TaskFinishDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"TaskOutcome","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"ConfirmationDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]}]},{"id":3,"title":"Вложения","type":"attachments","attachments":{},"collapsed":true,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[]}]}}]}',
'FieldRefs':[title_TasksField.insertedId,  created_TasksField.insertedId, createdBy_TasksField.insertedId,modified_TasksField.insertedId, modifiedBy_TasksField.insertedId,docState_TasksField.insertedId,
contentType_TasksField.insertedId,
iconType_TasksField.insertedId,
dsParentLink_TasksField.insertedId,
instruction.insertedId,
assignedTo.insertedId,
stageDelegate.insertedId,
assignedToGroup.insertedId,
taskDueDate.insertedId,
taskAuthor.insertedId,
taskStartDate.insertedId,
taskReason.insertedId,
taskType.insertedId,
taskOutcome.insertedId,
completed.insertedId,
stageComment.insertedId,
taskDelegationComment.insertedId,
priority.insertedId,
taskCoexecutors.insertedId,
taskController.insertedId,
confirmRequired.insertedId,
observers.insertedId,
acquaintanceDate.insertedId,
executedBy.insertedId,
taskFinishDate.insertedId,
taskConfirmDate.insertedId 
],
'Properties':
{ 
'is_ItemInitializator' : 'Conteq.iSpace.Tasks.Services.Initialization.TasksBaseInitializer',
'DefaultTaskDecisions' : {'ReturnTaskToAuthorActionAvailable':true, 'DelegateTaskActionAvailable':true},
'TaskDecisions' : [{'Command':'{7E904999-13A0-4319-8B3D-3E85B7360589}', 'Title':'Ознакомлен(а)', 'TaskOutcome':'Ознакомлен(а)', 'State':'Task_Completed', 'RequiredComment':false, 'RedirectPage':1}] 
},
'DefaultFieldValues':{
'Title':'Ознакомление',
'TaskType':'Ознакомление'
}
});

executionTask = db.home.DsContentTypes.insertOne(
{
'Name':'Исполнение',
'StaticName':'ExecutionTask',
'FileSysObjectType':2,
'ParentListId':taskList._id, 
'FormStateJson':'[{"Role":null,"Name":"\u041F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":null,"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":true,"ReadOnly":false},{"Name":"TaskDueDate","Hidden":false,"Required":true,"ReadOnly":false},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"StageComment","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskStartDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"StageDelegate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAcknowledgeDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[{"Id":"Conteq.iSpace.WebApi.Actions.AddAttachmentAction","Visible":true,"Enabled":true},{"Id":"Conteq.iSpace.WebApi.Actions.RevokeDocumentAction","Visible":true,"Enabled":true},{"Id":"Conteq.iSpace.Tasks.Actions.CreateTaskAction","Visible":true,"Enabled":true},{"Id":"Conteq.iSpace.Routes.Actions.RevokeAction","Visible":false,"Enabled":true}],"Priority":1},{"Role":"64257a713111d8ce589d6e49","Name":"\u041D\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u002B \u0430\u0434\u043C\u0438\u043D","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddaf","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"StageDelegate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u002B \u0430\u0432\u0442\u043E\u0440","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddaf","TypeAsString":"DocumentState"}},{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"CreatedBy","Value":"Me","TypeAsString":"User"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"RequiredConfirmation","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"StageDelegate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u002B \u043A\u043E\u043C\u0443","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddaf","TypeAsString":"DocumentState"}},{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"AssignedTo","Value":"Me","TypeAsString":"UserMulti"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Observers","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskCoexecutors","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"RequiredConfirmation","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"StageDelegate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u002B \u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddaf","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Observers","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskCoexecutors","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"RequiredConfirmation","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskFinishDate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"StageDelegate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1},{"Role":"64257a713111d8ce589d6e49","Name":"\u041D\u0430 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0435 \u002B \u0430\u0434\u043C\u0438\u043D","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddb0","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":true,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskFinishDate","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"StageDelegate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0438 \u002B \u0430\u0432\u0442\u043E\u0440","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddb0","TypeAsString":"DocumentState"}},{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"TaskAuthor","Value":"Me","TypeAsString":"User"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"RequiredConfirmation","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskOutcome","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageDelegate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ConfirmationDate","Hidden":false,"Required":false,"ReadOnly":true}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0438 \u002B \u043A\u043E\u043C\u0443","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddb0","TypeAsString":"DocumentState"}},{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"AssignedTo","Value":"Me","TypeAsString":"UserMulti"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskOutcome","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageDelegate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0438 \u002B \u043A\u043E\u043D\u0442\u0440\u043E\u043B\u0435\u0440","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddb0","TypeAsString":"DocumentState"}},{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"TaskController","Value":"Me","TypeAsString":"UserMulti"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Observers","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskCoexecutors","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"RequiredConfirmation","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskOutcome","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageDelegate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u041D\u0430 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0438 \u002B \u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddb0","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Observers","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskCoexecutors","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"RequiredConfirmation","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskOutcome","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageDelegate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ConfirmationDate","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0430/\u041E\u0442\u043C\u0435\u043D\u0435\u043D\u0430","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":2,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddb4","TypeAsString":"DocumentState"}},{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddb2","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"Title","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskController","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"Observers","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskCoexecutors","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"RequiredConfirmation","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskOutcome","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageDelegate","Hidden":true,"Required":false,"ReadOnly":false},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ConfirmationDate","Hidden":false,"Required":false,"ReadOnly":true}],"ActionSettings":[],"Priority":1},{"Role":null,"Name":"\u0414\u0435\u043B\u0435\u0433\u0438\u0440\u043E\u0432\u0430\u043D\u0430","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":{"ClosureOperator":1,"NestedConditions":[{"ClosureOperator":0,"NestedConditions":null,"FieldCondition":{"ConditionOperator":6,"Field":"DocState","Value":"644106a1365263e2af37ddb3","TypeAsString":"DocumentState"}}],"FieldCondition":null},"FieldSettings":[{"Name":"AssignedTo","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskDueDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Title","Hidden":false,"Required":true,"ReadOnly":true},{"Name":"Instruction","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"StageComment","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskReason","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskController","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Observers","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskCoexecutors","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"RequiredConfirmation","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAuthor","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskStartDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ExecutedBy","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskFinishDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskOutcome","Hidden":true,"Required":false,"ReadOnly":true},{"Name":"StageDelegate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"TaskAcknowledgeDate","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ConfirmationDate","Hidden":false,"Required":false,"ReadOnly":true}],"ActionSettings":[],"Priority":1}]',
'FormJson':'{"fields":["TaskAuthor","TaskPriority","AssignedToGroup","TaskFinishDate","TaskAcknowledgeDate","ConfirmationDate","TaskStartDate","StageDelegate","Completed","Modified","ModifiedBy","CreatedBy","TaskOutcomeComment","AssignedTo","TaskController","ExecutedBy","Observers","Title","Instruction","TaskReason","TaskOutcome","Created","TaskCoexecutors","DocState","TaskDueDate","ParentLink","TaskSubject","ItemIcon","TaskType","RequiredConfirmation"],"formType":"page","tabs":[{"key":"ItemProps","title":"Задача","type":"itemProps","metadata":{"sections":[{"id":0,"title":"","collapsed":false,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[{"colls":[{"name":"AssignedTo","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"TaskDueDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"Title","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]},{"colls":[{"name":"Instruction","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]},{"colls":[{"name":"StageComment","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]},{"colls":[{"name":"TaskReason","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]}]},{"id":1,"title":"Дополнительные параметры","collapsed":true,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[{"colls":[{"name":"TaskController","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"Observers","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"TaskCoexecutors","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"RequiredConfirmation","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md4"}]}]},{"id":2,"title":"Исполнение","collapsed":true,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[{"colls":[{"name":"TaskAuthor","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"TaskStartDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"ExecutedBy","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"TaskFinishDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"TaskOutcome","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"StageDelegate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"TaskAcknowledgeDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"ConfirmationDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6","additionalSettings":{"displayValueFilled":true}}]}]},{"id":3,"title":"Вложения","type":"attachments","attachments":{},"collapsed":true,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[]}]}}]}',
'FieldRefs':[title_TasksField.insertedId,  created_TasksField.insertedId, createdBy_TasksField.insertedId,modified_TasksField.insertedId, modifiedBy_TasksField.insertedId,docState_TasksField.insertedId,
contentType_TasksField.insertedId,
iconType_TasksField.insertedId,
dsParentLink_TasksField.insertedId,
instruction.insertedId,
assignedTo.insertedId,
stageDelegate.insertedId,
assignedToGroup.insertedId,
taskDueDate.insertedId,
completed.insertedId,
taskReason.insertedId,
taskType.insertedId,
taskOutcome.insertedId,
stageComment.insertedId,
taskDelegationComment.insertedId,
taskAuthor.insertedId,
taskStartDate.insertedId,
priority.insertedId,
taskCoexecutors.insertedId,
taskController.insertedId,
confirmRequired.insertedId,
observers.insertedId,
acquaintanceDate.insertedId,
executedBy.insertedId,
taskFinishDate.insertedId,
taskConfirmDate.insertedId 
],
'Properties':
{ 
'is_ItemInitializator' : 'Conteq.iSpace.Tasks.Services.Initialization.TasksBaseInitializer',
'DefaultTaskDecisions' : {'ReturnTaskToAuthorActionAvailable':true, 'DelegateTaskActionAvailable':true},
'TaskDecisions' : [{'Command':'{324C7EFD-D360-492D-A042-A0D7EF3A716C}', 'Title':'Исполнить', 'TaskOutcome':'Исполнено', 'State':'Task_Completed', 'RequiredComment':false, 'RedirectPage':1}] 
},
'DefaultFieldValues':{
'Title':'Исполнение',
'TaskType':'Исполнение'
}
});
/*============ End Template Task ============*/


/*============ Begin DsPages List ============*/

pageLib = ({
  '_id':'DsPages',
  'Name':'Страницы сайта',
  'Description':'Библиотека создания страниц сайта.',
  'ListUrl':'DsPages',
  'ListType':200,
  'EnableFolderCreation':false,
  'SystemList':false,
  'State':0,
  'SiteId':'home',
  "HasUniquePermissions":false,
  "SecureObjectId":"home",
  "Properties.is_eventreceivers": "[{ \"Name\": \"Conteq.iSpace.Pages.EventReceivers.DsPagesEventReceiver\", \"Type\": 1 },{ \"Name\": \"Conteq.iSpace.Pages.EventReceivers.DsPagesEventReceiver\", \"Type\": 3 }]"
});
db.home.DsLists.insertOne(pageLib);

title_PagesField = db.home.DsFields.insertOne({'Name':'Title', '_t': 'MongoTextField', 'DisplayName':'Название', 'FieldType': textFT.insertedId, 'ParentList':'DsPages', 'Required':true, 'SystemField':true, 'ParentFieldId':title.insertedId})
created_PagesField = db.home.DsFields.insertOne({'Name':'Created', '_t': 'MongoDateTimeField', 'DisplayName':'Создано', 'FieldType': dateFT.insertedId, 'ParentList':'DsPages', 'Required':false, 'SystemField':true, 'ParentFieldId':created.insertedId})
modified_PagesField = db.home.DsFields.insertOne({'Name':'Modified', '_t': 'MongoDateTimeField', 'DisplayName':'Изменено', 'FieldType': dateFT.insertedId, 'ParentList':'DsPages', 'Required':false, 'SystemField':true, 'ParentFieldId':modified.insertedId})
modifiedBy_PagesField = db.home.DsFields.insertOne({'Name':'ModifiedBy', '_t': 'MongoUserField', 'DisplayName':'Кем изменено', 'FieldType': userFT.insertedId, 'ParentList':'DsPages', 'Required':false, 'SystemField':true, 'LookupField':'Name', 'SourceType':0, 'ValueType':[0],'TargetGroup':null, 'ParentFieldId':modifiedBy.insertedId})
createdBy_PagesField = db.home.DsFields.insertOne({'Name':'CreatedBy', '_t': 'MongoUserField', 'DisplayName':'Кем создано', 'FieldType': userFT.insertedId, 'ParentList':'DsPages', 'Required':false, 'SystemField':true, 'LookupField':'Name', 'SourceType':0, 'ValueType':[0],'TargetGroup':null, 'ParentFieldId':createdBy.insertedId})
docState_PagesField = db.home.DsFields.insertOne({'Name':'DocState', '_t': 'MongoDocumentStateField', 'DisplayName':'Состояние', 'FieldType': docStateFT.insertedId, 'ParentList':'DsPages', 'Required':false, 'SystemField':true, 'ParentFieldId':docState.insertedId})
iconType_PagesField = db.home.DsFields.insertOne({'Name':'ItemIcon', '_t': 'MongoIconTypeField', 'DisplayName':'Тип (иконка)', 'FieldType': iconTypeFT.insertedId, 'ParentList':'DsPages', 'Required':false, 'SystemField':true, 'ParentFieldId':iconType.insertedId})
contentType_PagesField = db.home.DsFields.insertOne({'Name':'ContentType', '_t': 'MongoTextField', 'DisplayName':'Тип контента', 'FieldType': textFT.insertedId, 'ParentList':'DsPages', 'Required':false, 'SystemField':true,'ParentFieldId':contentType.insertedId})

pageUrl = db.home.DsFields.insertOne({'Name':'PageUrl', '_t': 'MongoTextField', 'DisplayName':'Ссылка', 'FieldType': textFT.insertedId, 'ParentList':pageLib._id, 'Required':true, 'SystemField':false})
pageDescription=db.home.DsFields.insertOne({'Name':'PageDescription', '_t': 'MongoNoteField', 'DisplayName':'Описание', 'FieldType': noteFT.insertedId, 'ParentList':pageLib._id, 'Required':false, 'SystemField':false, 'DisplayFormat':0, 'RowCount':2});
pageEditorF=db.home.DsFields.insertOne({'Name':'WebPartPageContent', '_t': 'MongoWebPartPageEditorField', 'DisplayName':'Разметка страницы', 'FieldType': webPartContentEditorFT.insertedId, 'ParentList':pageLib._id, 'Required':false, 'SystemField':false, 'Hidden':true});
published=db.home.DsFields.insertOne({'Name':'PagePublished', '_t': 'MongoBooleanField', 'DisplayName':'Опубликована', 'FieldType': boolFT.insertedId, 'ParentList':pageLib._id, 'Required':false, 'SystemField':false});
showNavigationMenu=db.home.DsFields.insertOne({'Name':'ShowNavigationMenu', '_t': 'MongoBooleanField', 'DisplayName':'Отображать навигационное меню', 'FieldType': boolFT.insertedId, 'ParentList':pageLib._id, 'Required':false, 'SystemField':false, 'DefaultValue':true });
isNewsItem=db.home.DsFields.insertOne({'Name':'IsNewsItem', '_t': 'MongoBooleanField', 'DisplayName':'Новостная страница', 'FieldType': boolFT.insertedId, 'ParentList':pageLib._id, 'Required':false, 'SystemField':false});
publishDate = db.home.DsFields.insertOne({'Name': 'PublishDate','_t': 'MongoDateTimeField','DisplayName': 'Дата публикации','FieldType': dateFT.insertedId, 'ParentList': 'DsPages', 'Required': false, 'SystemField': false, 'Hidden': false, 'FieldHint': null, 'ParentFieldId': null, 'DateOnly': true, 'ManualDateEntry': true, 'DateLtTodayDenied': true, 'ShowIndicator': false, 'UseStaticTime': false, 'DefaultIndicatorColor': null, 'DefaultValueFormula': null, 'NotDisplayIndicatorForState': null, 'IndicatorColorSettings': [ { 'DaysBeforeDate': 0, 'Color': '' } ] });

pageLibView = db.home.DsViews.insertOne({'Name':'Все страницы', 'ParentList':pageLib._id, 'Filter':null, 'Sort':'{"FieldInternalName":"Created","Order":-1}', 'ShowFolder':false, 'PageSize':50,
'Fields':[
  {'FieldId': title_PagesField.insertedId, 'Position': 1},
  {'FieldId': pageDescription.insertedId, 'Position': 2},
  {'FieldId': docState_PagesField.insertedId, 'Position': 3},
  {'FieldId': created_PagesField.insertedId, 'Position': 4},
  {'FieldId': createdBy_PagesField.insertedId, 'Position': 5},
  {'FieldId': modified_PagesField.insertedId, 'Position': 6},
  {'FieldId': modifiedBy_PagesField.insertedId, 'Position': 7}
]});


db.home.DsLists.updateOne(
{'ListUrl':'DsPages'},
{$set: { "DefaultView" : pageLibView.insertedId}});


pageCntType = db.home.DsContentTypes.insertOne(
{
'Name':'Страница',
'StaticName':'DsPage',
'FileSysObjectType':3,
'ParentListId':pageLib._id, 
'FormActionJson':null,
'FormStateJson':'[{"Role":null,"Name":"\u041F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E","TaskExecutor":false,"DocState":[],"Groups":[],"Filter":null,"FieldSettings":[{"Name":"Title","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"PageDescription","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ShowNavigationMenu","Required":false,"ReadOnly":false,"Hidden":false},{"Name":"PageUrl","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"WebPartPageContent","Hidden":false,"Required":false,"ReadOnly":false},{"Name":"CreatedBy","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Created","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"ModifiedBy","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"Modified","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"DocState","Hidden":false,"Required":false,"ReadOnly":true},{"Name":"PagePublished","Hidden":true,"Required":false,"ReadOnly":false}],"ActionSettings":[{"Id":"Conteq.iSpace.Registration.Actions.RegisterItemAction","Visible":false,"Enabled":true},{"Id":"Conteq.iSpace.Tasks.Actions.CreateTaskAction","Visible":false,"Enabled":true},{"Id":"Conteq.iSpace.DigSign.Actions.SignAction","Visible":false,"Enabled":true},{"Id":"Conteq.iSpace.Routes.Actions.StartRouteAction","Visible":false,"Enabled":true},{"Id":"Conteq.iSpace.Routes.Actions.RevokeAction","Visible":false,"Enabled":true},{"Id":"Conteq.iSpace.WebApi.Actions.CreateChildDocumentAction","Visible":false,"Enabled":true},{"Id":"Conteq.iSpace.WebApi.Actions.AttachDocumentTemplateAction","Visible":false,"Enabled":true},{"Id":"Conteq.iSpace.WebApi.Actions.DeleteCardAction","Visible":false,"Enabled":true},{"Id":"Conteq.iSpace.WebApi.Actions.EditCardAction","Visible":true,"Enabled":true},{"Id":"Conteq.iSpace.WebApi.Actions.CopyItemAction","Visible":true,"Enabled":true},{"Id":"Conteq.iSpace.WebApi.Actions.AddAttachmentAction","Visible":false,"Enabled":true},{"Id":"Conteq.iSpace.WebApi.Actions.RevokeDocumentAction","Visible":false,"Enabled":true},{"Id":"Conteq.iSpace.WebApi.Actions.PrintFormAction","Visible":false,"Enabled":true}],"Priority":1}]',
'FormJson':'{"formType":"page","tabs":[{"key":"ItemProps","title":"Страница","type":"itemProps","metadata":{"sections":[{"id":0,"title":"Общая информация","collapsed":false,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[{"colls":[{"name":"Title","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]},{"colls":[{"name":"PageDescription","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]},{"colls":[{"name":"ShowNavigationMenu","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]},{"colls":[{"name":"PageUrl","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]},{"colls":[{"name":"IsNewsItem","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]},{"colls":[{"name":"PublishDate","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md2","additionalSettings":{"displayValueFilled":false,"displayRule":"IsNewsItem=Да"}}]}]},{"id":1,"title":"Редактор","collapsed":false,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[{"colls":[{"name":"WebPartPageContent","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md12"}]}]},{"id":2,"title":"Служебная информация","collapsed":false,"displayAll":false,"showTooltip":false,"textTooltip":"","rows":[{"colls":[{"name":"CreatedBy","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"Created","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"ModifiedBy","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"Modified","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"}]},{"colls":[{"name":"DocState","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md6"},{"name":"PagePublished","required":false,"readOnly":false,"hidden":false,"widthRules":"ms-md4"}]}]}]}}]}',
'FieldRefs':[
  title_PagesField.insertedId,
  created_PagesField.insertedId,
  createdBy_PagesField.insertedId,
  modified_PagesField.insertedId,
  modifiedBy_PagesField.insertedId,
  docState_PagesField.insertedId,
  contentType_PagesField.insertedId,
  pageUrl.insertedId,
  pageDescription.insertedId,
  pageEditorF.insertedId,
  published.insertedId,
  showNavigationMenu.insertedId,
  isNewsItem.insertedId,
  publishDate.insertedId
],
'Properties':{'is_ItemInitializator':'Conteq.iSpace.Pages.Initialization.DsPageLinkInitialization'}
});

db.DsDocumentStates.insertOne(
{'Title':'Опубликована', 'ContentTypeId':pageCntType.insertedId, 'StaticName':'PagePublished'}
)
/*============ End DsPages List ============*/

/*============ Notification Templates ============*/
db.home.DsNotificationTemplates.insertOne({
  "_id": "TaskCreated_ToExecutor",
  "Title": "Задача на исполнение",
  "IsActive": false,
  "Notifications": [
    {
      "Lcid": 1049,
      "Subject": "Задача на исполнение",
      "Body": '<p>Назначена задача [$Properties:ItemUrl]<br><br><strong>Автор:</strong> [$Item:CreatedBy.Name]<br><strong>Кому назначена:</strong> [$Item:AssignedTo.Name]<br><strong>Срок исполнения:</strong> [$Item:TaskDueDate]<br><br> <br>Если задача назначена на группу пользователей - перед началом выполнения необходимо взять ее в работу, выбрав соответствующее решение на форме задачи.<br><br> <br>[$Properties:SiteUrl]<br><br> <br><span style="font-size: 11px; color: rgb(102, 102, 102);">Данное письмо сгенерировано автоматически, пожалуйста, не отвечайте на него.</span><br></p>'
    }
  ]
})

db.home.DsNotificationTemplates.insertOne({
  "_id": "TaskCreated_ToCoexecutors",
  "Title": "Назначение соисполнителем по задаче",
  "IsActive": false,
  "Notifications": [
    {
      "Lcid": 1049,
      "Subject": "Назначение соисполнителем по задаче",
      "Body": '<p>Вы назначены соисполнителем по задаче [$Properties:ItemUrl]<br><br><strong>Автор:</strong> [$Item:CreatedBy.Name]<br><strong>Кому назначена:</strong> [$Item:AssignedTo.Name]<br><strong>Срок исполнения:</strong> [$Item:TaskDueDate]<br><br> <br>Если задача назначена на группу пользователей - перед началом выполнения необходимо взять ее в работу, выбрав соответствующее решение на форме задачи.<br><br> <br>[$Properties:SiteUrl]<br><br> <br><span style="font-size: 11px; color: rgb(102, 102, 102);">Данное письмо сгенерировано автоматически, пожалуйста, не отвечайте на него.</span><br></p>'
    }
  ]
})

db.home.DsNotificationTemplates.insertOne({
  "_id": "TaskCreated_ToObservers",
  "Title": "Назначение наблюдателем по задаче",
  "IsActive": false,
  "Notifications": [
    {
      "Lcid": 1049,
      "Subject": "Назначение наблюдателем по задаче",
      "Body": '<p>Вы назначены наблюдателем по задаче [$Properties:ItemUrl]<br><br><strong>Автор:</strong> [$Item:CreatedBy.Name]<br><strong>Кому назначена:</strong> [$Item:AssignedTo.Name]<br><strong>Срок исполнения:</strong> [$Item:TaskDueDate]<br><br> <br>Если задача назначена на группу пользователей - перед началом выполнения необходимо взять ее в работу, выбрав соответствующее решение на форме задачи.<br><br> <br>[$Properties:SiteUrl]<br><br> <br><span style="font-size: 11px; color: rgb(102, 102, 102);">Данное письмо сгенерировано автоматически, пожалуйста, не отвечайте на него.</span><br></p>'
    }
  ]
})

db.home.DsNotificationTemplates.insertOne({
  "_id": "TaskCreated_ToController",
  "Title": "Назначение контролером по задаче",
  "IsActive": false,
  "Notifications": [
    {
      "Lcid": 1049,
      "Subject": "Назначение контролером по задаче",
      "Body": '<p>Вы назначены контролером по задаче [$Properties:ItemUrl]<br><br><strong>Автор:</strong> [$Item:CreatedBy.Name]<br><strong>Кому назначена:</strong> [$Item:AssignedTo.Name]<br><strong>Срок исполнения:</strong> [$Item:TaskDueDate]<br><br> <br>Если задача назначена на группу пользователей - перед началом выполнения необходимо взять ее в работу, выбрав соответствующее решение на форме задачи.<br><br> <br>[$Properties:SiteUrl]<br><br> <br><span style="font-size: 11px; color: rgb(102, 102, 102);">Данное письмо сгенерировано автоматически, пожалуйста, не отвечайте на него.</span><br></p>'
    }
  ]
})

db.home.DsNotificationTemplates.insertOne({
  "_id": "TaskCanceled_ToAllParticipants",
  "Title": "Задача отменена",
  "IsActive": false,
  "Notifications": [
    {
      "Lcid": 1049,
      "Subject": "Задача отменена",
      "Body": '<p>Задача [$Properties:ItemUrl] была отменена.<br><br><strong>Комментарий:</strong> [$Item:StageComment]<br><strong>Автор:</strong> [$Item:CreatedBy.Name]<br><strong>Кому назначена:</strong> [$Item:AssignedTo.Name]<br><strong>Срок исполнения:</strong> [$Item:TaskDueDate]<br><br>  <br>[$Properties:SiteUrl]<br><br> <br><span style="font-size: 11px; color: rgb(102, 102, 102);">Данное письмо сгенерировано автоматически, пожалуйста, не отвечайте на него.</span><br></p>'
    }
  ]
})

db.home.DsNotificationTemplates.insertOne({
  "_id": "TaskExpired",
  "Title": "Срок выполнения задач истек",
  "IsActive": false,
  "Notifications": [
    {
      "Lcid": 1049,
      "Subject": "Срок выполнения задач истек",
      "Body": '<style> table, td, th { border: 1px solid; padding: 5px 10px 5px 10px; } table { border-collapse: collapse; } </style><p>Срок выполнения задач истек:<br><br>[$Properties:TasksTable]<br><br>[$Properties:SiteUrl]<br><br> <br><span style="font-size: 11px; color: rgb(102, 102, 102);">Данное письмо сгенерировано автоматически, пожалуйста, не отвечайте на него.</span><br></p>'
    }
  ]
})
 
db.home.DsNotificationTemplates.insertOne({
  "_id": "TaskWillSoonExpire",
  "Title": "Истекает срок выполнения задач",
  "IsActive": false,
  "Notifications": [
    {
      "Lcid": 1049,
      "Subject": "Истекает срок выполнения задач",
      "Body": '<style> table, td, th { border: 1px solid; padding: 5px 10px 5px 10px; } table { border-collapse: collapse; } </style><p>Срок выполнения задач наступает менее, чем через 24 ч.:<br><br>[$Properties:TasksTable]<br><br>[$Properties:SiteUrl]<br><br> <br><span style="font-size: 11px; color: rgb(102, 102, 102);">Данное письмо сгенерировано автоматически, пожалуйста, не отвечайте на него.</span><br></p>'
    }
  ]
})

db.home.DsNotificationTemplates.insertOne({
  "_id": "ItemDelete_Failed",
  "Title": "Удаление элемента завершилось неуспешно",
  "IsActive": false,
  "Notifications": [
    {
      "Lcid": 1049,
      "Subject": "Удаление элемента завершилось неуспешно",
      "Body": "<p>При попытке удаления [$Properties:ItemUrl] возникла проблема, не позволяющая удалить элемент: [$Properties:Error]</p>"
    }
  ]
})

db.home.DsNotificationTemplates.insertOne({
  "_id": "TaskComplete_ToControllerAndAuthor",
  "Title": "Задача завершена",
  "IsActive": false,
  "Notifications": [
    {
      "Lcid": 1049,
      "Subject": "Завершение задачи исполнителем",
      "Body": '<p>Задача [$Properties:ItemUrl] завершена.<br><br><strong>Комментарий:</strong> [$Item:StageComment]<br><strong>Автор:</strong> [$Item:CreatedBy.Name]<br><strong>Кому назначена:</strong> [$Item:AssignedTo.Name]<br><strong>Срок исполнения:</strong> [$Item:TaskDueDate]<br><br>  <br>[$Properties:SiteUrl]<br><br> <br><span style="font-size: 11px; color: rgb(102, 102, 102);">Данное письмо сгенерировано автоматически, пожалуйста, не отвечайте на него.</span><br></p>'
    }
  ]
})

db.home.DsNotificationTemplates.insertOne({
  "_id": "TaskReturnToAuthor_ToAuthor",
  "Title": "Задача возвращена",
  "IsActive": false,
  "Notifications": [
    {
      "Lcid": 1049,
      "Subject": "Задача возвращена исполнителем",
      "Body": '<p>Исполнитель отказался от выполнения задачи [$Properties:ItemUrl].<br><br><strong>Комментарий:</strong> [$Item:StageComment]<br><strong>Автор:</strong> [$Item:CreatedBy.Name]<br><strong>Кому назначена:</strong> [$Item:AssignedTo.Name]<br><strong>Срок исполнения:</strong> [$Item:TaskDueDate]<br><br>  <br>[$Properties:SiteUrl]<br><br> <br><span style=\"font-size: 11px; color: rgb(102, 102, 102);\">Данное письмо сгенерировано автоматически, пожалуйста, не отвечайте на него.</span><br></p>'
    }
  ]
})

db.home.DsNotificationTemplates.insertOne({
  "_id": "TaskReturnToExecutor_ToExecutors",
  "Title": "Отклонение выполнения задачи",
  "IsActive": false,
  "Notifications": [
    {
      "Lcid": 1049,
      "Subject": "Отклонение выполнения задачи",
      "Body": '<p>Отклонение выполнения задачи [$Properties:ItemUrl].<br><br><strong>Комментарий:</strong> [$Item:StageComment]<br><strong>Автор:</strong> [$Item:CreatedBy.Name]<br><strong>Кому назначена:</strong> [$Item:AssignedTo.Name]<br><strong>Срок исполнения:</strong> [$Item:TaskDueDate]<br><br>  <br>[$Properties:SiteUrl]<br><br> <br><span style="font-size: 11px; color: rgb(102, 102, 102);">Данное письмо сгенерировано автоматически, пожалуйста, не отвечайте на него.</span><br></p>'
    }
  ]
})
db.home.DsNotificationTemplates.insertOne({
  "_id": "TaskApproval_ToController",
  "Title": "Задача на подтверждении",
  "IsActive": false,
  "Notifications": [
    {
      "Lcid": 1049,
      "Subject": "Задача на подтверждении",
      "Body": '<p>Задача на подтверждении [$Properties:ItemUrl].<br><br><strong>Комментарий:</strong> [$Item:StageComment]<br><strong>Автор:</strong> [$Item:CreatedBy.Name]<br><strong>Кому назначена:</strong> [$Item:AssignedTo.Name]<br><strong>Срок исполнения:</strong> [$Item:TaskDueDate]<br><br>  <br>[$Properties:SiteUrl]<br><br> <br><span style="font-size: 11px; color: rgb(102, 102, 102);">Данное письмо сгенерировано автоматически, пожалуйста, не отвечайте на него.</span><br></p>'
    }
  ]
})

db.home.DsNotificationTemplates.insertOne({
  "_id": "Deputies_AssignedAsReplacer",
  "Title": "Назначение заместителем/помощником",
  "IsActive": false,
  "Notifications": [
    {
      "Lcid": 1049,
      "Subject": "Вы назначены заместителем/помощником",
      "Body": "<p>Вы назначены заместителем/помощником<br><br>Замещаемый пользователь: [$Properties:Replaced]<br>Замещающий пользователь: [$Properties:Replacer]<br>Тип замещения: [$Properties:Type]<br>Дата начала: [$Properties:From]<br>Дата окончания: [$Properties:Until]<br><br><br>[$Properties:TasksTable]<br>[$Properties:SiteUrl]<br><br><br><span style=\"font-size: 11px; color: rgb(102, 102, 102);\">Данное письмо сгенерировано автоматически, пожалуйста, не отвечайте на него.</span><br></p>"
    }
  ]
})

db.home.DsNotificationTemplates.insertOne({
  "_id": "VerifyCodes_ResetPasswordCode",
  "Title": "Код восстановления",
  "IsActive": false,
  "Notifications": [
    {
      "Lcid": 1049,
      "Subject": "Код восстановления",
      "Body": "<p>Ваш код для восстановления <b>[$Properties:Code]</b>.</p>"
    }
  ]
})

db.home.DsNotificationTemplates.insertOne({
  "_id": "Collection_Indexed_To_ElasticSearch_Correctly",
  "Title": "Коллекция добавлена в поисковую систему",
  "IsActive": false,
  "Notifications": [
    {
      "Lcid": 1049,
      "Subject": "Коллекция добавлена в поисковую систему",
      "Body": "<p>Коллекция <b>[$Properties:ListId]</b> добавлена в поисковую систему.</p><p>Элементов загружено успешно: <b>[$Properties:IndexedElements]</b>.</p><p>Ошибки: <b>[$Properties:FailedElements]</b></p>"
    }
  ]
})

db.home.DsNotificationTemplates.insertOne({
  "_id": "Collection_Indexed_To_ElasticSearch_With_Error",
  "Title": "Ошибка добавления коллекции в поисковую систему",
  "IsActive": false,
  "Notifications": [
    {
      "Lcid": 1049,
      "Subject": "Ошибка добавления коллекции в поисковую систему",
      "Body": "<p>Ошибка добавления коллекции <b>[$Properties:ListId]</b> в поисковую систему.</p><p>Содержание ошибки: <b>[$Properties:Error]</b>.</p>"
    }
  ]
})

db.home.DsNotificationTemplates.insertOne({
  "_id": "TaskCreated_ToDelegate",
  "Title": "Задача делегирована",
  "IsActive": false,
  "Notifications": [
    {
      "Lcid": 1049,
      "Subject": "Задача делегирована",
      "Body": '<p>Делегирование задачи [$Properties:ItemUrl] <br><br> <br>[$Properties:SiteUrl]<br><br> <br><span style="font-size: 11px; color: rgb(102, 102, 102);">Данное письмо сгенерировано автоматически, пожалуйста, не отвечайте на него.</span><br></p>'
    }
  ]
})

db.home.DsNotificationTemplates.insertOne({
  "_id": "Item_Shared",
  "Title": "Предоставлен доступ к элементу",
  "IsActive": false,
  "Notifications": [
    {
      "Lcid": 1049,
      "Subject": "Вам предоставили доступ",
      "Body": "<p>Пользователь [$Properties:Sender] поделился с Вами</p><p>Комментарий: [$Properties:Comment]</p><p>[$Properties:ItemsTable]</p>"
    }
  ]
})

db.home.DsNotificationTemplates.insertOne({
  "_id": "TechnicalSupport_Add",
  "Title": "Запрос в техническую поддержку",
  "IsActive": false,
  "Notifications": [
    {
      "Lcid": 1049,
      "Subject": "Новый запрос в техническую поддержку",
      "Body": "<p>Новый запрос в техническую поддержку - [$Properties:ItemUrl]</p>"
    }
  ]
})

db.home.DsNotificationTemplates.insertOne({
  "_id": "ExtractionXlsx_Completed",
  "Title": "Экспорт в xlsx завершён",
  "IsActive": false,
  "Notifications": [
    {
      "Lcid": 1049,
      "Subject": "[$Properties:Filename]",
      "Body": "<p>По Вашему запросу произведена выгрузка <a href=\"[$Properties:FileUrl]\">[$Properties:Filename]</a></p>"
    }
  ]
})

db.home.DsNotificationTemplates.insertOne({
  "_id": "ExtractionXlsx_Error",
  "Title": "Экспорт завершён с ошибкой",
  "IsActive": false,
  "Notifications": [
    {
      "Lcid": 1049,
      "Subject": "Экспорт завершён с ошибкой",
      "Body": "<p>Экспорт завершён с ошибкой</p>"
    }
  ]
})

db.home.DsNotificationTemplates.insertOne({
  "_id": "SendAttachments",
  "Title": "Отправить",
  "IsActive": false,
  "Notifications": [
    {
      "Lcid": 1049,
      "Subject": "Отправить",
      "Body": "<p>[$Properties:SiteUrl]</p>"
    }
  ]
})

db.home.DsNotificationTemplates.insertOne({
  "_id": "SyncFieldsStageAction_Error",
  "Title": "Ошибка при синхронизации полей",
  "IsActive": true,
  "Notifications": [
    {
      "Lcid": 1049,
      "Subject": "Ошибка при синхронизации полей",
      "Body": "<p>Ошибка при синхронизации полей: [$Properties:ItemUrl]</p>"
    }
  ]
})
/*============ End Notification Templates ============*/

/*============ Create  iSpaceTimer database ============*/
db = db.getSiblingDB('iSpaceTimer');  // Создание базы данных
db.createCollection('test_collection');  // Создание коллекции


/*============ Create  iSpaceAuditLogs database ============*/
db = db.getSiblingDB('iSpaceAuditLogs');  // Создание базы данных
db.createCollection('UserActivitiesAuditLogs');  // Создание коллекции


/*=========================== далее свободное творчество ======================*/


// 1. Переключаемся на БД admin и создаём пользователя
db = db.getSiblingDB('admin');

// Авторизация с помощью root-пользователя (напр., MONGO_INITDB_ROOT_USERNAME)
db.auth(
  process.env.MONGO_INITDB_ROOT_USERNAME,
  process.env.MONGO_INITDB_ROOT_PASSWORD
);


const database = 'iSpaceTimer';
use(database);


db.createUser({
  user: 'iUser',
  pwd: 'S0hvKxItG7',
  roles: [
    { role: 'readWrite', db: 'iSpaceTimer' },
    { role: 'dbAdmin', db: 'iSpaceTimer' }
  ]
});

print("✅ Пользователь iUser создан в БД admin");

db = db.getSiblingDB('iSpaceTimer');
db.runCommand({ ping: 10 });
print("✅ Подключение к БД iSpaceTimer успешно");



const database = 'iSpaceContent';
use(database);


db.createUser({
  user: 'iUser',
  pwd: 'S0hvKxItG7',
  roles: [
    { role: 'readWrite', db: 'iSpaceContent' },
    { role: 'dbAdmin', db: 'iSpaceContent' }
  ]
});

print("✅ Пользователь iUser создан в БД admin");

db = db.getSiblingDB('iSpaceContent');
db.runCommand({ ping: 10 });
print("✅ Подключение к БД iSpaceContent успешно");


const database = 'iSpaceAuditLogs';
use(database);


db.createUser({
  user: 'iUser',
  pwd: 'S0hvKxItG7',
  roles: [
    { role: 'readWrite', db: 'iSpaceAuditLogs' },
    { role: 'dbAdmin', db: 'iSpaceAuditLogs' }
  ]
});

print("✅ Пользователь iUser создан в БД admin");

db = db.getSiblingDB('iSpaceAuditLogs');
db.runCommand({ ping: 10 });
print("✅ Подключение к БД iSpaceAuditLogs успешно");
